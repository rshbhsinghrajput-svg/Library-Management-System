package com.library;

/**
 * Book.java — A simple model class representing a book in the library.
 *
 * Each book has:
 *   - bookId          : A unique ID for the book (e.g., "B001")
 *   - title           : The title of the book
 *   - author          : The author's name
 *   - publisher       : The publisher's name
 *   - totalCopies     : How many copies the library owns in total
 *   - availableCopies : How many copies are currently available (not borrowed)
 *
 * This class is used to pass book data around in the program.
 * In MongoDB, each book is stored as a document in the 'books' collection.
 */
public class Book {

    // ========== Fields ==========

    private String bookId;          // Unique book identifier
    private String title;           // Title of the book
    private String author;          // Author name
    private String publisher;       // Publisher name
    private int totalCopies;        // Total copies the library owns
    private int availableCopies;    // Copies currently on the shelf (not issued)

    // ========== Constructor ==========

    /**
     * Creates a new Book with all details.
     *
     * @param bookId          Unique ID for the book
     * @param title           Book title
     * @param author          Author name
     * @param publisher       Publisher name
     * @param totalCopies     Total number of copies
     * @param availableCopies Number of copies currently available
     */
    public Book(String bookId, String title, String author, String publisher,
                int totalCopies, int availableCopies) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
    }

    // ========== Getters ==========

    public String getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    // ========== Setters ==========

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setTotalCopies(int totalCopies) {
        this.totalCopies = totalCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    // ========== Display ==========

    /**
     * Returns a nicely formatted string with the book's details.
     * Useful for printing book info in the console.
     */
    @Override
    public String toString() {
        return "| Book ID: " + bookId
             + " | Title: " + title
             + " | Author: " + author
             + " | Publisher: " + publisher
             + " | Total Copies: " + totalCopies
             + " | Available: " + availableCopies + " |";
    }
}
