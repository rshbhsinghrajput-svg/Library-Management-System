package com.library.ui;

import com.library.Book;
import com.library.DatabaseConnection;
import com.library.LibraryManager;
import com.library.LoanRecord;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * LibrarianView.java — Librarian workspace with KPI metrics, Catalog CRUD, Circulation, and Overdue Dashboard.
 */
public class LibrarianView extends VBox {

    private String librarianName;
    private LibraryManager manager;
    private DatabaseConnection db;

    private Label statTotalBooks;
    private Label statActiveLoans;
    private Label statOverdueCount;

    private TableView<Book> catalogTable;
    private TableView<OverdueEntry> overdueTable;

    public static class OverdueEntry {
        public String rollNo;
        public String studentName;
        public String bookId;
        public String bookTitle;
        public String issueDate;
        public String dueDate;
        public long daysLate;
        public double fineAmount;

        public OverdueEntry(String rollNo, String studentName, String bookId, String bookTitle,
                            String issueDate, String dueDate, long daysLate, double fineAmount) {
            this.rollNo = rollNo;
            this.studentName = studentName;
            this.bookId = bookId;
            this.bookTitle = bookTitle;
            this.issueDate = issueDate;
            this.dueDate = dueDate;
            this.daysLate = daysLate;
            this.fineAmount = fineAmount;
        }
    }

    public LibrarianView(String librarianName, LibraryManager manager, DatabaseConnection db) {
        this.librarianName = librarianName;
        this.manager = manager;
        this.db = db;

        setPadding(new Insets(16, 24, 24, 24));
        setSpacing(16);

        // Header Banner with Metrics
        getChildren().addAll(createMetricsBar(), createMainTabPane());

        refreshData();
    }

    private HBox createMetricsBar() {
        HBox box = new HBox(16);
        box.setAlignment(Pos.CENTER_LEFT);

        statTotalBooks = new Label("0");
        statTotalBooks.getStyleClass().add("stat-card-number");
        VBox card1 = createStatCard("Total Titles in Catalog", statTotalBooks);

        statActiveLoans = new Label("0");
        statActiveLoans.getStyleClass().add("stat-card-number");
        VBox card2 = createStatCard("Currently Issued Books", statActiveLoans);

        statOverdueCount = new Label("0");
        statOverdueCount.getStyleClass().add("stat-card-number");
        statOverdueCount.setStyle("-fx-text-fill: #DC2626;");
        VBox card3 = createStatCard("Overdue Loans (Active)", statOverdueCount);

        HBox.setHgrow(card1, Priority.ALWAYS);
        HBox.setHgrow(card2, Priority.ALWAYS);
        HBox.setHgrow(card3, Priority.ALWAYS);

        box.getChildren().addAll(card1, card2, card3);
        return box;
    }

    private VBox createStatCard(String labelText, Label numLabel) {
        VBox card = new VBox(4);
        card.getStyleClass().add("stat-card");
        Label lbl = new Label(labelText);
        lbl.getStyleClass().add("stat-card-label");
        card.getChildren().addAll(numLabel, lbl);
        return card;
    }

    private TabPane createMainTabPane() {
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        VBox.setVgrow(tabPane, Priority.ALWAYS);

        Tab tabCatalog = new Tab("📚 Book Catalog (CRUD)", createCatalogTab());
        Tab tabCirculation = new Tab("🔄 Circulation Desk (Issue / Return)", createCirculationTab());
        Tab tabOverdue = new Tab("⚠️ Overdue Report Dashboard", createOverdueTab());
        Tab tabCollect = new Tab("💰 Collect Fines", createCollectFineTab());

        tabPane.getTabs().addAll(tabCatalog, tabCirculation, tabOverdue, tabCollect);
        return tabPane;
    }

    // ==========================================
    // Tab 1: Book Catalog (CRUD)
    // ==========================================
    private VBox createCatalogTab() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16));

        HBox actions = new HBox(12);
        actions.setAlignment(Pos.CENTER_LEFT);

        Button addBtn = new Button("➕ Add New Book");
        addBtn.getStyleClass().add("btn-gold");

        Button editBtn = new Button("✏️ Edit Book Copies/Details");
        editBtn.getStyleClass().add("btn-secondary");

        Button refreshBtn = new Button("🔄 Refresh Catalog");
        refreshBtn.getStyleClass().add("btn-secondary");

        actions.getChildren().addAll(addBtn, editBtn, refreshBtn);

        catalogTable = new TableView<>();
        VBox.setVgrow(catalogTable, Priority.ALWAYS);

        TableColumn<Book, String> colId = new TableColumn<>("Book ID");
        colId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBookId()));
        colId.setPrefWidth(100);

        TableColumn<Book, String> colTitle = new TableColumn<>("Title");
        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTitle()));
        colTitle.setPrefWidth(280);

        TableColumn<Book, String> colAuthor = new TableColumn<>("Author");
        colAuthor.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAuthor()));
        colAuthor.setPrefWidth(200);

        TableColumn<Book, String> colPub = new TableColumn<>("Publisher");
        colPub.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPublisher()));
        colPub.setPrefWidth(180);

        TableColumn<Book, Number> colTotal = new TableColumn<>("Total Copies");
        colTotal.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getTotalCopies()));
        colTotal.setPrefWidth(100);

        TableColumn<Book, Number> colAvail = new TableColumn<>("Available");
        colAvail.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getAvailableCopies()));
        colAvail.setPrefWidth(100);

        catalogTable.getColumns().addAll(colId, colTitle, colAuthor, colPub, colTotal, colAvail);

        addBtn.setOnAction(e -> showAddBookDialog());
        editBtn.setOnAction(e -> {
            Book selected = catalogTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a book from the table to edit.");
                return;
            }
            showEditBookDialog(selected);
        });
        refreshBtn.setOnAction(e -> refreshData());

        box.getChildren().addAll(actions, catalogTable);
        return box;
    }

    private void showAddBookDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Add New Book to BBAU Library");
        dialog.setHeaderText("Enter Book Details");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField idField = new TextField();
        idField.setPromptText("Book ID (e.g. B001)");

        TextField titleField = new TextField();
        titleField.setPromptText("Title");

        TextField authorField = new TextField();
        authorField.setPromptText("Author");

        TextField pubField = new TextField();
        pubField.setPromptText("Publisher");

        TextField copiesField = new TextField("5");
        copiesField.setPromptText("Total Copies");

        grid.add(new Label("Book ID:"), 0, 0);
        grid.add(idField, 1, 0);
        grid.add(new Label("Title:"), 0, 1);
        grid.add(titleField, 1, 1);
        grid.add(new Label("Author:"), 0, 2);
        grid.add(authorField, 1, 2);
        grid.add(new Label("Publisher:"), 0, 3);
        grid.add(pubField, 1, 3);
        grid.add(new Label("Total Copies:"), 0, 4);
        grid.add(copiesField, 1, 4);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                String id = idField.getText().trim();
                String title = titleField.getText().trim();
                String author = authorField.getText().trim();
                String pub = pubField.getText().trim();
                int copies;
                try {
                    copies = Integer.parseInt(copiesField.getText().trim());
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Invalid Number", "Copies must be a positive integer.");
                    return;
                }
                boolean added = manager.addBook(id, title, author, pub, copies);
                if (added) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Book added successfully!");
                    refreshData();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Failed", "Could not add book. Book ID may already exist.");
                }
            }
        });
    }

    private void showEditBookDialog(Book book) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit Book: " + book.getBookId());
        dialog.setHeaderText("Modify details (leave unchanged to keep current values)");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField titleField = new TextField(book.getTitle());
        TextField authorField = new TextField(book.getAuthor());
        TextField pubField = new TextField(book.getPublisher());
        TextField copiesField = new TextField(String.valueOf(book.getTotalCopies()));

        grid.add(new Label("Title:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Author:"), 0, 1);
        grid.add(authorField, 1, 1);
        grid.add(new Label("Publisher:"), 0, 2);
        grid.add(pubField, 1, 2);
        grid.add(new Label("Total Copies:"), 0, 3);
        grid.add(copiesField, 1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    int newTotal = Integer.parseInt(copiesField.getText().trim());
                    boolean updated = manager.editBook(book.getBookId(), titleField.getText().trim(),
                            authorField.getText().trim(), pubField.getText().trim(), newTotal);
                    if (updated) {
                        showAlert(Alert.AlertType.INFORMATION, "Updated", "Book updated successfully!");
                        refreshData();
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Failed", "Could not update book.");
                    }
                } catch (Exception ex) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Invalid copies number.");
                }
            }
        });
    }

    // ==========================================
    // Tab 2: Circulation Desk
    // ==========================================
    private VBox createCirculationTab() {
        VBox box = new VBox(20);
        box.setPadding(new Insets(20));

        HBox panels = new HBox(30);

        // Issue Panel
        VBox issuePanel = new VBox(12);
        issuePanel.getStyleClass().add("card-panel");
        issuePanel.setPrefWidth(420);

        Label issueTitle = new Label("📥 Issue Book to Student");
        issueTitle.getStyleClass().add("card-title");

        TextField issueRoll = new TextField();
        issueRoll.setPromptText("Student Roll Number");

        TextField issueName = new TextField();
        issueName.setPromptText("Student Name");

        TextField issueBookId = new TextField();
        issueBookId.setPromptText("Book ID");

        Button doIssueBtn = new Button("Issue Book (30 Days)");
        doIssueBtn.getStyleClass().add("btn-gold");

        doIssueBtn.setOnAction(e -> {
            String roll = issueRoll.getText().trim();
            String name = issueName.getText().trim();
            String bid = issueBookId.getText().trim();
            if (roll.isEmpty() || name.isEmpty() || bid.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please enter Roll Number, Student Name, and Book ID.");
                return;
            }
            String loanId = manager.issueBook(roll, name, bid);
            if (loanId != null) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Book successfully issued!\nLoan ID: " + loanId + "\nDue Date: " + LocalDate.now().plusDays(30));
                issueRoll.clear();
                issueName.clear();
                issueBookId.clear();
                refreshData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not issue book. Check Book ID and available copies.");
            }
        });

        issuePanel.getChildren().addAll(issueTitle, new Label("Student Roll Number:"), issueRoll,
                new Label("Student Name:"), issueName, new Label("Book ID:"), issueBookId, doIssueBtn);

        // Return Panel
        VBox returnPanel = new VBox(12);
        returnPanel.getStyleClass().add("card-panel");
        returnPanel.setPrefWidth(420);

        Label returnTitle = new Label("↩️ Process Book Return");
        returnTitle.getStyleClass().add("card-title");

        TextField retRoll = new TextField();
        retRoll.setPromptText("Student Roll Number");

        TextField retBookId = new TextField();
        retBookId.setPromptText("Book ID");

        Button doReturnBtn = new Button("Process Return");
        doReturnBtn.getStyleClass().add("btn-primary");

        doReturnBtn.setOnAction(e -> {
            String roll = retRoll.getText().trim();
            String bid = retBookId.getText().trim();
            if (roll.isEmpty() || bid.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Missing Fields", "Please enter Roll Number and Book ID.");
                return;
            }
            double fine = manager.returnBook(roll, bid);
            if (fine < 0) {
                showAlert(Alert.AlertType.ERROR, "Error", "No active borrow record found for this Student and Book.");
            } else if (fine == 0) {
                showAlert(Alert.AlertType.INFORMATION, "Returned", "Book returned on time! No fine.");
                retRoll.clear();
                retBookId.clear();
                refreshData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Overdue Fine", String.format("Book returned overdue!\nOverdue fine charged: ₹%.0f (at ₹50/day).", fine));
                retRoll.clear();
                retBookId.clear();
                refreshData();
            }
        });

        returnPanel.getChildren().addAll(returnTitle, new Label("Student Roll Number:"), retRoll,
                new Label("Book ID:"), retBookId, doReturnBtn);

        panels.getChildren().addAll(issuePanel, returnPanel);
        box.getChildren().add(panels);
        return box;
    }

    // ==========================================
    // Tab 3: Overdue Report Dashboard
    // ==========================================
    private VBox createOverdueTab() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16));

        Label info = new Label("⚠️ Real-time dashboard showing all active loans past their 30-day return due date (Accruing ₹50/day).");
        info.setStyle("-fx-text-fill: #DC2626; -fx-font-weight: bold; -fx-font-size: 13px;");

        overdueTable = new TableView<>();
        VBox.setVgrow(overdueTable, Priority.ALWAYS);

        TableColumn<OverdueEntry, String> colRoll = new TableColumn<>("Roll No");
        colRoll.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().rollNo));
        colRoll.setPrefWidth(110);

        TableColumn<OverdueEntry, String> colName = new TableColumn<>("Student");
        colName.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().studentName));
        colName.setPrefWidth(160);

        TableColumn<OverdueEntry, String> colBook = new TableColumn<>("Book ID");
        colBook.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().bookId));
        colBook.setPrefWidth(90);

        TableColumn<OverdueEntry, String> colTitle = new TableColumn<>("Title");
        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().bookTitle));
        colTitle.setPrefWidth(240);

        TableColumn<OverdueEntry, String> colDue = new TableColumn<>("Due Date");
        colDue.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().dueDate));
        colDue.setPrefWidth(110);

        TableColumn<OverdueEntry, Number> colLate = new TableColumn<>("Days Late");
        colLate.setCellValueFactory(c -> new SimpleIntegerProperty((int) c.getValue().daysLate));
        colLate.setPrefWidth(90);

        TableColumn<OverdueEntry, String> colFine = new TableColumn<>("Live Fine");
        colFine.setCellValueFactory(c -> new SimpleStringProperty(String.format("₹%.0f", c.getValue().fineAmount)));
        colFine.setPrefWidth(110);

        overdueTable.getColumns().addAll(colRoll, colName, colBook, colTitle, colDue, colLate, colFine);

        box.getChildren().addAll(info, overdueTable);
        return box;
    }

    // ==========================================
    // Tab 4: Collect Fines
    // ==========================================
    private VBox createCollectFineTab() {
        VBox box = new VBox(16);
        box.setPadding(new Insets(20));

        VBox card = new VBox(12);
        card.getStyleClass().add("card-panel");
        card.setMaxWidth(500);

        Label title = new Label("💰 Collect Student Overdue Fine");
        title.getStyleClass().add("card-title");

        TextField rollField = new TextField();
        rollField.setPromptText("Enter Student Roll Number");

        Button collectBtn = new Button("Mark Student Fines as Paid");
        collectBtn.getStyleClass().add("btn-gold");

        collectBtn.setOnAction(e -> {
            String roll = rollField.getText().trim();
            if (roll.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Missing Roll Number", "Please enter a student roll number.");
                return;
            }
            manager.updateLiveOverdueFines(roll);
            boolean paid = manager.payAllFines(roll);
            if (paid) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Fines for " + roll + " marked as collected/paid!");
                rollField.clear();
                refreshData();
            } else {
                showAlert(Alert.AlertType.INFORMATION, "No Fines", "Student has no outstanding unpaid fines.");
            }
        });

        card.getChildren().addAll(title, new Label("Student Roll Number:"), rollField, collectBtn);
        box.getChildren().add(card);
        return box;
    }

    public void refreshData() {
        // Refresh catalog table
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books";
        try (PreparedStatement stmt = db.getConnection().prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                books.add(new Book(
                        rs.getString("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("publisher"),
                        rs.getInt("total_copies"),
                        rs.getInt("available_copies")
                ));
            }
        } catch (SQLException ex) {
            // ignore
        }
        catalogTable.setItems(FXCollections.observableArrayList(books));

        // Calculate metrics
        int totalBooks = books.size();
        int activeLoans = 0;
        int overdueLoans = 0;

        List<OverdueEntry> overdueList = new ArrayList<>();
        String loanSql = "SELECT * FROM loans WHERE returned = FALSE";
        LocalDate today = LocalDate.now();

        try (PreparedStatement stmt = db.getConnection().prepareStatement(loanSql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                activeLoans++;
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                if (today.isAfter(dueDate)) {
                    overdueLoans++;
                    long days = ChronoUnit.DAYS.between(dueDate, today);
                    double fine = days * 50.0;
                    overdueList.add(new OverdueEntry(
                            rs.getString("roll_no"),
                            rs.getString("student_name"),
                            rs.getString("book_id"),
                            rs.getString("book_title"),
                            rs.getDate("issue_date").toString(),
                            dueDate.toString(),
                            days,
                            fine
                    ));
                }
            }
        } catch (SQLException ex) {
            // ignore
        }

        statTotalBooks.setText(String.valueOf(totalBooks));
        statActiveLoans.setText(String.valueOf(activeLoans));
        statOverdueCount.setText(String.valueOf(overdueLoans));

        overdueTable.setItems(FXCollections.observableArrayList(overdueList));
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
