package com.library.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.InputStream;

/**
 * UIHeader.java — Reusable institutional top header for BBAU Lucknow.
 * Displays the official BBAU crest in a crisp gold-bordered frame alongside
 * the university name and Gautam Buddha Central Library title.
 */
public class UIHeader extends HBox {

    private Button logoutButton;
    private Label userSessionLabel;

    public UIHeader(Runnable onLogout) {
        getStyleClass().add("header-banner");
        setAlignment(Pos.CENTER_LEFT);
        setSpacing(18);
        setPadding(new Insets(12, 24, 12, 24));

        // 1. Official BBAU Logo in a framed badge
        ImageView logoView = new ImageView();
        try {
            InputStream is = getClass().getResourceAsStream("/images/bbau_logo.png");
            if (is == null) {
                is = getClass().getResourceAsStream("/images/bbau_logo.jpg");
            }
            if (is != null) {
                Image logo = new Image(is);
                logoView.setImage(logo);
                logoView.setFitHeight(62);
                logoView.setFitWidth(62);
                logoView.setPreserveRatio(true);
                logoView.setSmooth(true);
            }
        } catch (Exception e) {
            System.out.println("⚠️ Could not load BBAU logo image: " + e.getMessage());
        }

        StackPane logoBadge = new StackPane(logoView);
        logoBadge.setStyle("-fx-background-color: #FFFFFF; "
                + "-fx-padding: 4px; "
                + "-fx-background-radius: 8px; "
                + "-fx-border-color: #DDA853; "
                + "-fx-border-radius: 8px; "
                + "-fx-border-width: 2px; "
                + "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.3), 4, 0, 0, 1);");
        logoBadge.setPrefSize(70, 70);
        logoBadge.setMinSize(70, 70);
        logoBadge.setMaxSize(70, 70);

        // 2. Bilingual Institutional Titles
        VBox titleBox = new VBox(2);
        titleBox.setAlignment(Pos.CENTER_LEFT);

        Label hindiTitle = new Label("बाबासाहेब भीमराव अम्बेडकर विश्वविद्यालय, लखनऊ");
        hindiTitle.getStyleClass().add("header-title-hindi");

        Label englishTitle = new Label("Babasaheb Bhimrao Ambedkar University (A Central University), Lucknow");
        englishTitle.getStyleClass().add("header-title-english");

        Label libraryTitle = new Label("Gautam Buddha Central Library — Library Management System");
        libraryTitle.getStyleClass().add("header-subtitle");

        titleBox.getChildren().addAll(hindiTitle, englishTitle, libraryTitle);

        // 3. Right Side: User Session Badge & Logout Button
        VBox rightBox = new VBox(6);
        rightBox.setAlignment(Pos.CENTER_RIGHT);

        userSessionLabel = new Label("Guest Mode");
        userSessionLabel.getStyleClass().add("header-status-badge");

        logoutButton = new Button("Exit / Logout");
        logoutButton.getStyleClass().add("btn-danger");
        logoutButton.setVisible(false);
        if (onLogout != null) {
            logoutButton.setOnAction(e -> onLogout.run());
        }

        rightBox.getChildren().addAll(userSessionLabel, logoutButton);

        // Spacer between left title and right status
        HBox spacer = new HBox();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        getChildren().addAll(logoBadge, titleBox, spacer, rightBox);
    }

    public void setSessionInfo(String text, boolean showLogout) {
        userSessionLabel.setText(text);
        logoutButton.setVisible(showLogout);
    }
}
