package com.library.ui;

import com.library.DatabaseConnection;
import com.library.LibraryManager;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.InputStream;
import java.util.Scanner;

/**
 * LibraryApp.java — Main JavaFX Application for BBAU Lucknow Gautam Buddha Central Library.
 * Includes official BBAU crest in the header and as an elegant background watermark.
 */
public class LibraryApp extends Application {

    private DatabaseConnection db;
    private LibraryManager manager;

    private StackPane mainContainer;
    private BorderPane rootLayout;
    private UIHeader header;
    private LoginView loginView;
    private ImageView watermarkView;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Babasaheb Bhimrao Ambedkar University, Lucknow — Gautam Buddha Central Library");

        // Set application taskbar/window icon to BBAU logo
        try {
            InputStream iconStream = getClass().getResourceAsStream("/images/bbau_logo.png");
            if (iconStream == null) {
                iconStream = getClass().getResourceAsStream("/images/bbau_logo.jpg");
            }
            if (iconStream != null) {
                primaryStage.getIcons().add(new Image(iconStream));
            }
        } catch (Exception ignored) {
        }

        // Initialize Database connection
        try {
            db = new DatabaseConnection((Scanner) null);
            manager = new LibraryManager(db);
        } catch (Exception e) {
            System.out.println("❌ Database initialization error: " + e.getMessage());
        }

        // Master container hosting the background watermark and the active UI
        mainContainer = new StackPane();
        mainContainer.setStyle("-fx-background-color: #F8FAFC;");

        // 1. Watermark Layer (Layer 0)
        watermarkView = new ImageView();
        try {
            InputStream watermarkStream = getClass().getResourceAsStream("/images/bbau_logo.png");
            if (watermarkStream == null) {
                watermarkStream = getClass().getResourceAsStream("/images/bbau_logo.jpg");
            }
            if (watermarkStream != null) {
                Image logo = new Image(watermarkStream);
                watermarkView.setImage(logo);
                watermarkView.setFitWidth(450);
                watermarkView.setFitHeight(450);
                watermarkView.setPreserveRatio(true);
                watermarkView.setSmooth(true);
                watermarkView.setOpacity(0.09); // Elegant institutional watermark
                watermarkView.setMouseTransparent(true);
            }
        } catch (Exception e) {
            System.out.println("⚠️ Could not load watermark image: " + e.getMessage());
        }

        StackPane watermarkPane = new StackPane(watermarkView);
        watermarkPane.setAlignment(Pos.CENTER);
        watermarkPane.setMouseTransparent(true);

        // 2. Active UI Layer (Layer 1)
        rootLayout = new BorderPane();
        rootLayout.setStyle("-fx-background-color: transparent;");

        // Top Institutional Header
        header = new UIHeader(this::showLoginView);
        rootLayout.setTop(header);

        // Center: Start with Login View
        loginView = new LoginView(db, this::onStudentLoginSuccess, this::onLibrarianLoginSuccess);
        rootLayout.setCenter(loginView);

        // Combine watermark in the back, UI in the front
        mainContainer.getChildren().addAll(watermarkPane, rootLayout);

        Scene scene = new Scene(mainContainer, 1180, 760);

        // Load custom BBAU theme stylesheet
        try {
            String css = getClass().getResource("/styles/bbau_theme.css").toExternalForm();
            scene.getStylesheets().add(css);
        } catch (Exception e) {
            System.out.println("⚠️ Could not load stylesheet: " + e.getMessage());
        }

        primaryStage.setScene(scene);
        primaryStage.setOnCloseRequest(e -> {
            if (db != null) {
                db.close();
            }
        });

        primaryStage.show();
    }

    private void showLoginView() {
        header.setSessionInfo("Guest Mode", false);
        rootLayout.setCenter(loginView);
    }

    private void onStudentLoginSuccess(String rollNo, String studentName) {
        header.setSessionInfo("🎓 Logged in as: " + studentName + " (" + rollNo + ")", true);
        StudentView studentView = new StudentView(rollNo, studentName, manager);
        studentView.setStyle("-fx-background-color: transparent;");
        rootLayout.setCenter(studentView);
    }

    private void onLibrarianLoginSuccess(String librarianName) {
        header.setSessionInfo("🔐 Librarian: " + librarianName, true);
        LibrarianView librarianView = new LibrarianView(librarianName, manager, db);
        librarianView.setStyle("-fx-background-color: transparent;");
        rootLayout.setCenter(librarianView);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
