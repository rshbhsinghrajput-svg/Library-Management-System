package com.library.ui;

import com.library.Book;
import com.library.LibraryManager;
import com.library.LoanRecord;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.util.List;

/**
 * StudentView.java — Student workspace with Catalog search, Active loans, Renewal, and Fines.
 */
public class StudentView extends VBox {

    private String rollNo;
    private String studentName;
    private LibraryManager manager;

    private TableView<Book> availableBooksTable;
    private TableView<LoanRecord> activeLoansTable;
    private TableView<LoanRecord> historyTable;

    public StudentView(String rollNo, String studentName, LibraryManager manager) {
        this.rollNo = rollNo;
        this.studentName = studentName;
        this.manager = manager;

        setPadding(new Insets(16, 24, 24, 24));
        setSpacing(16);

        // Student Welcome Banner
        HBox welcomeBanner = new HBox(12);
        welcomeBanner.setAlignment(Pos.CENTER_LEFT);
        welcomeBanner.setStyle("-fx-background-color: #FFFFFF; -fx-padding: 12px 20px; -fx-background-radius: 8px; -fx-border-color: #E2E8F0; -fx-border-radius: 8px;");

        Label nameLabel = new Label("Student: " + studentName + " (Roll No: " + rollNo + ")");
        nameLabel.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #0B2545;");

        HBox bannerSpacer = new HBox();
        HBox.setHgrow(bannerSpacer, Priority.ALWAYS);

        Button refreshAllBtn = new Button("🔄 Refresh Workspace");
        refreshAllBtn.getStyleClass().add("btn-secondary");
        refreshAllBtn.setOnAction(e -> refreshAllData());

        welcomeBanner.getChildren().addAll(nameLabel, bannerSpacer, refreshAllBtn);

        // Tab Pane
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        VBox.setVgrow(tabPane, Priority.ALWAYS);

        Tab tabCatalog = new Tab("🔍 Browse & Borrow Books", createCatalogTab());
        Tab tabLoans = new Tab("📖 My Active Borrowings", createActiveLoansTab());
        Tab tabFines = new Tab("💳 Pay Overdue Fine", createPayFineTab());
        Tab tabHistory = new Tab("📜 Borrowing History", createHistoryTab());

        tabPane.getTabs().addAll(tabCatalog, tabLoans, tabFines, tabHistory);

        getChildren().addAll(welcomeBanner, tabPane);

        refreshAllData();
    }

    // ==========================================
    // Tab 1: Catalog & Borrowing
    // ==========================================
    private VBox createCatalogTab() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16));

        HBox searchBar = new HBox(12);
        searchBar.setAlignment(Pos.CENTER_LEFT);

        TextField searchField = new TextField();
        searchField.setPromptText("Filter by title, author, or book ID...");
        searchField.setPrefWidth(350);

        Button borrowBtn = new Button("📥 Borrow Selected Book");
        borrowBtn.getStyleClass().add("btn-gold");

        searchBar.getChildren().addAll(new Label("Live Search:"), searchField, borrowBtn);

        availableBooksTable = new TableView<>();
        VBox.setVgrow(availableBooksTable, Priority.ALWAYS);

        TableColumn<Book, String> colId = new TableColumn<>("Book ID");
        colId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBookId()));
        colId.setPrefWidth(100);

        TableColumn<Book, String> colTitle = new TableColumn<>("Title");
        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTitle()));
        colTitle.setPrefWidth(300);

        TableColumn<Book, String> colAuthor = new TableColumn<>("Author");
        colAuthor.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getAuthor()));
        colAuthor.setPrefWidth(200);

        TableColumn<Book, String> colPub = new TableColumn<>("Publisher");
        colPub.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPublisher()));
        colPub.setPrefWidth(180);

        TableColumn<Book, Number> colCopies = new TableColumn<>("Available");
        colCopies.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getAvailableCopies()));
        colCopies.setPrefWidth(90);

        availableBooksTable.getColumns().addAll(colId, colTitle, colAuthor, colPub, colCopies);

        // Search Filter
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            filterBooks(newVal);
        });

        borrowBtn.setOnAction(e -> {
            Book selected = availableBooksTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a book from the table to borrow.");
                return;
            }

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Book Borrowing");
            confirm.setHeaderText("Borrow: " + selected.getTitle() + " [" + selected.getBookId() + "]");
            confirm.setContentText("Return Due Date will be 30 days from today (" + LocalDate.now().plusDays(30) + ").\nDo you want to proceed?");
            if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
                String loanId = manager.issueBook(rollNo, studentName, selected.getBookId());
                if (loanId != null) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Book successfully issued!\nLoan ID: " + loanId + "\nDue Date: " + LocalDate.now().plusDays(30));
                    refreshAllData();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Borrowing Failed", "Could not borrow book. You may already have an active unreturned copy, or no copies are available.");
                }
            }
        });

        box.getChildren().addAll(searchBar, availableBooksTable);
        return box;
    }

    private void filterBooks(String query) {
        List<Book> list = manager.getAvailableBooks();
        if (query == null || query.trim().isEmpty()) {
            availableBooksTable.setItems(FXCollections.observableArrayList(list));
            return;
        }
        String q = query.toLowerCase().trim();
        ObservableList<Book> filtered = FXCollections.observableArrayList();
        for (Book b : list) {
            if (b.getTitle().toLowerCase().contains(q) ||
                b.getAuthor().toLowerCase().contains(q) ||
                b.getBookId().toLowerCase().contains(q)) {
                filtered.add(b);
            }
        }
        availableBooksTable.setItems(filtered);
    }

    // ==========================================
    // Tab 2: Active Borrowings & Renewal
    // ==========================================
    private VBox createActiveLoansTab() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16));

        HBox topBox = new HBox(12);
        topBox.setAlignment(Pos.CENTER_LEFT);

        Label info = new Label("ℹ️ Books can be renewed ONLY on or before the 30-day due date (extends due date by +30 days).");
        info.setStyle("-fx-font-size: 12px; -fx-text-fill: #1E3A8A; -fx-font-weight: bold;");

        HBox spacer = new HBox();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button renewBtn = new Button("🔄 Renew Selected (+30 Days)");
        renewBtn.getStyleClass().add("btn-primary");

        Button returnBtn = new Button("↩️ Return Selected Book");
        returnBtn.getStyleClass().add("btn-secondary");

        topBox.getChildren().addAll(info, spacer, renewBtn, returnBtn);

        activeLoansTable = new TableView<>();
        VBox.setVgrow(activeLoansTable, Priority.ALWAYS);

        TableColumn<LoanRecord, String> colLoanId = new TableColumn<>("Loan ID");
        colLoanId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getLoanId()));
        colLoanId.setPrefWidth(130);

        TableColumn<LoanRecord, String> colBookId = new TableColumn<>("Book ID");
        colBookId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBookId()));
        colBookId.setPrefWidth(90);

        TableColumn<LoanRecord, String> colTitle = new TableColumn<>("Book Title");
        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBookTitle()));
        colTitle.setPrefWidth(260);

        TableColumn<LoanRecord, String> colIssue = new TableColumn<>("Issue Date");
        colIssue.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getIssueDate().toString()));
        colIssue.setPrefWidth(110);

        TableColumn<LoanRecord, String> colDue = new TableColumn<>("Due Date");
        colDue.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDueDate().toString()));
        colDue.setPrefWidth(110);

        TableColumn<LoanRecord, String> colRenewals = new TableColumn<>("Renewals");
        colRenewals.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getRenewalCount())));
        colRenewals.setPrefWidth(80);

        TableColumn<LoanRecord, String> colStatus = new TableColumn<>("Status");
        colStatus.setCellValueFactory(c -> {
            LocalDate due = c.getValue().getDueDate();
            boolean overdue = LocalDate.now().isAfter(due);
            return new SimpleStringProperty(overdue ? "OVERDUE (Fine Accruing)" : "Active (OK)");
        });
        colStatus.setPrefWidth(160);

        activeLoansTable.getColumns().addAll(colLoanId, colBookId, colTitle, colIssue, colDue, colRenewals, colStatus);

        renewBtn.setOnAction(e -> {
            LoanRecord selected = activeLoansTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select an active loan to renew.");
                return;
            }
            if (LocalDate.now().isAfter(selected.getDueDate())) {
                showAlert(Alert.AlertType.ERROR, "Renewal Disallowed", "This book is already overdue! Overdue books cannot be renewed.\nPlease return the book and pay the fine.");
                return;
            }
            boolean success = manager.renewBook(rollNo, selected.getLoanId());
            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Renewed", "Book renewed successfully!\nNew Due Date: " + selected.getDueDate().plusDays(30));
                refreshAllData();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not renew book.");
            }
        });

        returnBtn.setOnAction(e -> {
            LoanRecord selected = activeLoansTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert(Alert.AlertType.WARNING, "Selection Required", "Please select a loan to return.");
                return;
            }
            double fine = manager.returnBook(rollNo, selected.getBookId());
            if (fine < 0) {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not process return.");
            } else if (fine == 0) {
                showAlert(Alert.AlertType.INFORMATION, "Returned", "Book returned on time! No fine incurred.");
                refreshAllData();
            } else {
                showAlert(Alert.AlertType.WARNING, "Overdue Return", String.format("Book returned overdue!\nOverdue fine charged: ₹%.0f (at ₹50/day).\nPlease settle in the Pay Fine tab.", fine));
                refreshAllData();
            }
        });

        box.getChildren().addAll(topBox, activeLoansTable);
        return box;
    }

    // ==========================================
    // Tab 3: Pay Overdue Fine
    // ==========================================
    private VBox createPayFineTab() {
        VBox box = new VBox(16);
        box.setPadding(new Insets(20));

        VBox fineCard = new VBox(12);
        fineCard.getStyleClass().add("card-panel");
        fineCard.setMaxWidth(600);

        Label title = new Label("💳 Fine Payment Counter (₹50 / Day Overdue)");
        title.getStyleClass().add("card-title");

        Label totalLabel = new Label("Outstanding Unpaid Fine: Calculating...");
        totalLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #DC2626;");

        HBox actions = new HBox(12);
        Button payAllBtn = new Button("Pay All Pending Fines");
        payAllBtn.getStyleClass().add("btn-gold");

        actions.getChildren().add(payAllBtn);

        fineCard.getChildren().addAll(title, totalLabel, actions);

        payAllBtn.setOnAction(e -> {
            manager.updateLiveOverdueFines(rollNo);
            boolean paid = manager.payAllFines(rollNo);
            if (paid) {
                showAlert(Alert.AlertType.INFORMATION, "Payment Successful", "All pending fines have been marked as paid!\nReceipt generated.");
                refreshAllData();
            } else {
                showAlert(Alert.AlertType.INFORMATION, "No Fines", "You do not have any unpaid fines.");
            }
        });

        box.getChildren().add(fineCard);
        return box;
    }

    // ==========================================
    // Tab 4: Borrowing History
    // ==========================================
    private VBox createHistoryTab() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16));

        historyTable = new TableView<>();
        VBox.setVgrow(historyTable, Priority.ALWAYS);

        TableColumn<LoanRecord, String> colLoanId = new TableColumn<>("Loan ID");
        colLoanId.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getLoanId()));
        colLoanId.setPrefWidth(130);

        TableColumn<LoanRecord, String> colTitle = new TableColumn<>("Book Title");
        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getBookTitle()));
        colTitle.setPrefWidth(260);

        TableColumn<LoanRecord, String> colIssue = new TableColumn<>("Issued");
        colIssue.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getIssueDate().toString()));
        colIssue.setPrefWidth(100);

        TableColumn<LoanRecord, String> colDue = new TableColumn<>("Due Date");
        colDue.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDueDate().toString()));
        colDue.setPrefWidth(100);

        TableColumn<LoanRecord, String> colReturn = new TableColumn<>("Returned Date");
        colReturn.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().isReturned() ? (c.getValue().getReturnDate() != null ? c.getValue().getReturnDate().toString() : "Returned") : "Active"
        ));
        colReturn.setPrefWidth(110);

        TableColumn<LoanRecord, String> colFine = new TableColumn<>("Fine (₹)");
        colFine.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getFineAmount() > 0 ? String.format("₹%.0f", c.getValue().getFineAmount()) : "-"
        ));
        colFine.setPrefWidth(90);

        TableColumn<LoanRecord, String> colPaid = new TableColumn<>("Fine Paid?");
        colPaid.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getFineAmount() > 0 ? (c.getValue().isFinePaid() ? "Yes" : "No (Pending)") : "-"
        ));
        colPaid.setPrefWidth(110);

        historyTable.getColumns().addAll(colLoanId, colTitle, colIssue, colDue, colReturn, colFine, colPaid);

        box.getChildren().add(historyTable);
        return box;
    }

    public void refreshAllData() {
        // Refresh Catalog
        availableBooksTable.setItems(FXCollections.observableArrayList(manager.getAvailableBooks()));

        // Refresh Active Loans
        List<LoanRecord> allRecords = manager.getBorrowingHistory(rollNo);
        ObservableList<LoanRecord> activeList = FXCollections.observableArrayList();
        for (LoanRecord r : allRecords) {
            if (!r.isReturned()) {
                activeList.add(r);
            }
        }
        activeLoansTable.setItems(activeList);

        // Refresh History
        historyTable.setItems(FXCollections.observableArrayList(allRecords));
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
