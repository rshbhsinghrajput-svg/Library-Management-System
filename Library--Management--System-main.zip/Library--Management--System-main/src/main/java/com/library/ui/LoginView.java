package com.library.ui;

import com.library.DatabaseConnection;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * LoginView.java — Role selection and authentication view (Student vs Librarian).
 */
public class LoginView extends VBox {

    private DatabaseConnection db;

    public LoginView(DatabaseConnection db,
                     BiConsumer<String, String> onStudentLogin,
                     Consumer<String> onLibrarianLogin) {
        this.db = db;
        setAlignment(Pos.CENTER);
        setPadding(new Insets(30));
        setSpacing(25);

        Label welcomeLabel = new Label("Welcome to BBAU Central Library Management Portal");
        welcomeLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #0B2545;");

        Label subLabel = new Label("Please select your role and enter your credentials to proceed");
        subLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

        // Two cards side by side
        HBox cardsBox = new HBox(30);
        cardsBox.setAlignment(Pos.CENTER);

        VBox studentCard = createStudentCard(onStudentLogin);
        VBox librarianCard = createLibrarianCard(onLibrarianLogin);

        cardsBox.getChildren().addAll(studentCard, librarianCard);
        getChildren().addAll(welcomeLabel, subLabel, cardsBox);
    }

    private VBox createStudentCard(BiConsumer<String, String> onStudentLogin) {
        VBox card = new VBox(14);
        card.getStyleClass().add("card-panel");
        card.setPrefWidth(380);
        card.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("🎓 Student Portal Access");
        title.getStyleClass().add("card-title");

        Label desc = new Label("Access book borrowing, 30-day renewals, and fine settlement.");
        desc.setStyle("-fx-text-fill: #64748B; -fx-font-size: 12px;");
        desc.setWrapText(true);

        TextField rollField = new TextField();
        rollField.setPromptText("Enter Roll Number (e.g. BBAU/2026/01)");

        TextField nameField = new TextField();
        nameField.setPromptText("Enter Full Student Name");

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: #EF4444; -fx-font-size: 12px;");
        errorLabel.setVisible(false);

        Button loginBtn = new Button("Enter Student Portal");
        loginBtn.getStyleClass().add("btn-gold");
        loginBtn.setMaxWidth(Double.MAX_VALUE);

        loginBtn.setOnAction(e -> {
            String roll = rollField.getText().trim();
            String name = nameField.getText().trim();
            if (roll.isEmpty() || name.isEmpty()) {
                errorLabel.setText("⚠️ Please enter both Roll Number and Name.");
                errorLabel.setVisible(true);
                return;
            }
            errorLabel.setVisible(false);
            onStudentLogin.accept(roll, name);
        });

        card.getChildren().addAll(title, desc, new Label("Student Roll Number:"), rollField,
                new Label("Student Name:"), nameField, errorLabel, loginBtn);
        return card;
    }

    private VBox createLibrarianCard(Consumer<String> onLibrarianLogin) {
        VBox card = new VBox(14);
        card.getStyleClass().add("card-panel");
        card.setPrefWidth(380);
        card.setAlignment(Pos.TOP_LEFT);

        Label title = new Label("🔐 Librarian Administration");
        title.getStyleClass().add("card-title");

        Label desc = new Label("Manage book catalog, circulation desk, and overdue tracking.");
        desc.setStyle("-fx-text-fill: #64748B; -fx-font-size: 12px;");
        desc.setWrapText(true);

        TextField idField = new TextField("lib123");
        idField.setPromptText("Librarian ID");

        PasswordField passField = new PasswordField();
        passField.setText("password123");
        passField.setPromptText("Password");

        Label hint = new Label("Default login: lib123 / password123");
        hint.setStyle("-fx-font-size: 11px; -fx-text-fill: #94A3B8;");

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: #EF4444; -fx-font-size: 12px;");
        errorLabel.setVisible(false);

        Button loginBtn = new Button("Access Librarian Console");
        loginBtn.getStyleClass().add("btn-primary");
        loginBtn.setMaxWidth(Double.MAX_VALUE);

        loginBtn.setOnAction(e -> {
            String id = idField.getText().trim();
            String pass = passField.getText().trim();

            if (id.isEmpty() || pass.isEmpty()) {
                errorLabel.setText("⚠️ ID and Password cannot be empty.");
                errorLabel.setVisible(true);
                return;
            }

            // Verify in MySQL
            Connection conn = db.getConnection();
            String sql = "SELECT name FROM librarians WHERE librarian_id = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, id);
                stmt.setString(2, pass);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String name = rs.getString("name");
                        errorLabel.setVisible(false);
                        onLibrarianLogin.accept(name);
                    } else {
                        errorLabel.setText("❌ Invalid Librarian ID or Password.");
                        errorLabel.setVisible(true);
                    }
                }
            } catch (SQLException ex) {
                errorLabel.setText("❌ Database error: " + ex.getMessage());
                errorLabel.setVisible(true);
            }
        });

        card.getChildren().addAll(title, desc, new Label("Librarian ID:"), idField,
                new Label("Password:"), passField, hint, errorLabel, loginBtn);
        return card;
    }
}
