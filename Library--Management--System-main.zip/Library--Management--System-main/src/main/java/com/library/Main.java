package com.library;

import com.library.ui.LibraryApp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 * Main.java — The entry point of the Library Management System for BBAU Lucknow.
 *
 * Launches the modern BBAU Lucknow JavaFX Desktop UI by default.
 * Supports fallback to Console Terminal mode if run with --console flag or in headless environments.
 */
public class Main {

    public static void main(String[] args) {
        // Check for explicit console argument
        for (String arg : args) {
            if ("--console".equalsIgnoreCase(arg) || "-c".equalsIgnoreCase(arg)) {
                runConsoleMode(args);
                return;
            }
        }

        // Launch JavaFX Desktop UI by default
        try {
            LibraryApp.main(args);
        } catch (Throwable t) {
            System.out.println("ℹ️ Launching Console Mode: " + t.getMessage());
            runConsoleMode(args);
        }
    }

    public static void runConsoleMode(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=========================================================");
        System.out.println("  🏛️ BABASAHEB BHIMRAO AMBEDKAR UNIVERSITY, LUCKNOW");
        System.out.println("     Gautam Buddha Central Library Management System");
        System.out.println("=========================================================");

        DatabaseConnection db = new DatabaseConnection(scanner);
        LibraryManager libraryManager = new LibraryManager(db, scanner);

        boolean running = true;

        while (running) {
            System.out.println("\n=========================================");
            System.out.println("         MAIN LOGIN SCREEN");
            System.out.println("=========================================");
            System.out.println("  1. Librarian Login");
            System.out.println("  2. Student Login");
            System.out.println("  3. Exit");
            System.out.println("=========================================");
            System.out.print("Enter your choice (1/2/3): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    handleLibrarianLogin(db, libraryManager, scanner);
                    break;
                case "2":
                    handleStudentLogin(libraryManager, scanner);
                    break;
                case "3":
                    running = false;
                    System.out.println("\n👋 Thank you for using the BBAU Central Library System. Goodbye!");
                    break;
                default:
                    System.out.println("⚠️  Invalid choice. Please enter 1, 2, or 3.");
            }
        }

        db.close();
        scanner.close();
    }

    private static void handleLibrarianLogin(DatabaseConnection db,
                                              LibraryManager libraryManager,
                                              Scanner scanner) {
        System.out.println("\n--- LIBRARIAN LOGIN ---");
        System.out.print("Enter Librarian ID: ");
        String libId = scanner.nextLine().trim();

        if (libId.isEmpty()) {
            System.out.println("⚠️  Librarian ID cannot be empty.");
            return;
        }

        System.out.print("Enter Password: ");
        String password = scanner.nextLine().trim();

        if (password.isEmpty()) {
            System.out.println("⚠️  Password cannot be empty.");
            return;
        }

        Connection conn = db.getConnection();
        String sql = "SELECT name FROM librarians WHERE librarian_id = ? AND password = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, libId);
            stmt.setString(2, password);

            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("❌ Invalid Librarian ID or Password. Please try again.");
                    return;
                }

                String libName = rs.getString("name");
                System.out.println("✅ Login successful! Welcome, " + libName + "!");
                showLibrarianMenu(libraryManager, scanner);
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error during login: " + e.getMessage());
        }
    }

    private static void showLibrarianMenu(LibraryManager libraryManager, Scanner scanner) {
        boolean loggedIn = true;

        while (loggedIn) {
            System.out.println("\n=========================================");
            System.out.println("         LIBRARIAN MENU");
            System.out.println("=========================================");
            System.out.println("  1. Add Book");
            System.out.println("  2. Edit Book");
            System.out.println("  3. Issue / Return Book");
            System.out.println("  4. Overdue Report Dashboard");
            System.out.println("  5. Collect Fine");
            System.out.println("  6. Check Available Books");
            System.out.println("  7. Logout");
            System.out.println("=========================================");
            System.out.print("Enter your choice (1-7): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    libraryManager.addBook();
                    break;
                case "2":
                    libraryManager.editBook();
                    break;
                case "3":
                    showIssueReturnSubmenu(libraryManager, scanner);
                    break;
                case "4":
                    libraryManager.overdueReportDashboard();
                    break;
                case "5":
                    libraryManager.collectFine();
                    break;
                case "6":
                    libraryManager.checkAvailableBooks();
                    break;
                case "7":
                    loggedIn = false;
                    System.out.println("🔒 Logged out from Librarian account.");
                    break;
                default:
                    System.out.println("⚠️  Invalid choice. Please enter a number between 1 and 7.");
            }
        }
    }

    private static void showIssueReturnSubmenu(LibraryManager libraryManager, Scanner scanner) {
        System.out.println("\n--- ISSUE / RETURN BOOK ---");
        System.out.println("  1. Issue a Book to a Student");
        System.out.println("  2. Return a Book for a Student");
        System.out.println("  3. Back");
        System.out.print("Enter your choice (1/2/3): ");

        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                libraryManager.issueBookAsLibrarian();
                break;
            case "2":
                libraryManager.returnBookAsLibrarian();
                break;
            case "3":
                break;
            default:
                System.out.println("⚠️  Invalid choice.");
        }
    }

    private static void handleStudentLogin(LibraryManager libraryManager, Scanner scanner) {
        System.out.println("\n--- STUDENT LOGIN ---");
        System.out.print("Enter Student Roll Number: ");
        String rollNo = scanner.nextLine().trim();

        if (rollNo.isEmpty()) {
            System.out.println("⚠️  Roll Number cannot be empty.");
            return;
        }

        System.out.print("Enter Student Name: ");
        String studentName = scanner.nextLine().trim();

        if (studentName.isEmpty()) {
            System.out.println("⚠️  Student Name cannot be empty.");
            return;
        }

        System.out.println("✅ Welcome, " + studentName + " (Roll No: " + rollNo + ")!");
        showStudentMenu(libraryManager, scanner, rollNo, studentName);
    }

    private static void showStudentMenu(LibraryManager libraryManager, Scanner scanner,
                                         String rollNo, String studentName) {
        boolean loggedIn = true;

        while (loggedIn) {
            System.out.println("\n=========================================");
            System.out.println("         STUDENT MENU");
            System.out.println("  Logged in as: " + studentName + " (" + rollNo + ")");
            System.out.println("=========================================");
            System.out.println("  1. Check Available Books");
            System.out.println("  2. Issue Book");
            System.out.println("  3. Renew Book");
            System.out.println("  4. Return Book");
            System.out.println("  5. Pay Fine");
            System.out.println("  6. Personal Borrowing History");
            System.out.println("  7. Logout");
            System.out.println("=========================================");
            System.out.print("Enter your choice (1-7): ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    libraryManager.checkAvailableBooks();
                    break;
                case "2":
                    libraryManager.issueBook(rollNo, studentName);
                    break;
                case "3":
                    libraryManager.renewBook(rollNo);
                    break;
                case "4":
                    libraryManager.returnBook(rollNo);
                    break;
                case "5":
                    libraryManager.payFine(rollNo);
                    break;
                case "6":
                    libraryManager.personalBorrowingHistory(rollNo);
                    break;
                case "7":
                    loggedIn = false;
                    System.out.println("🔒 Logged out from Student account.");
                    break;
                default:
                    System.out.println("⚠️  Invalid choice. Please enter a number between 1 and 7.");
            }
        }
    }
}
