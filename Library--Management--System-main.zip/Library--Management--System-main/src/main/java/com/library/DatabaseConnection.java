package com.library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 * DatabaseConnection.java — Handles connecting to MySQL via JDBC and setting up database tables.
 *
 * What this class does:
 *   1. Connects to MySQL server (or provided JDBC connection)
 *   2. Creates the "library_db" database if it doesn't already exist
 *   3. Initializes all 4 relational tables:
 *        - books       : stores book records
 *        - students    : stores student records
 *        - librarians  : stores librarian login credentials
 *        - loans       : stores borrowing records with foreign key constraints
 *   4. Seeds a default librarian account (id: "lib123", password: "password123")
 *      if the librarians table is empty.
 *   5. Provides the active SQL Connection to the rest of the application.
 */
public class DatabaseConnection {

    private static final String DB_NAME = "library_db";
    private static final String BASE_URL = "jdbc:mysql://localhost:3306/";
    private static final String PARAMS = "?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "Sql@2026";

    private Connection connection;

    /**
     * Initializes the connection using default configured credentials ("root" / "Sql@2026"),
     * falling back to prompting the user in console mode if needed.
     *
     * @param scanner Scanner for user input from console if prompt is needed
     */
    public DatabaseConnection(Scanner scanner) {
        System.out.println("Connecting to MySQL Database...");

        // Try connecting with default credentials first for seamless startup
        String fullUrl = BASE_URL + DB_NAME + PARAMS;
        try {
            connection = DriverManager.getConnection(fullUrl, DEFAULT_USER, DEFAULT_PASSWORD);
            System.out.println("✅ Connected to MySQL successfully (Database: " + DB_NAME + ")!");
            initDatabaseTables();
            seedDefaultLibrarian();
            return;
        } catch (SQLException e) {
            System.out.println("ℹ️ Default credentials did not connect: " + e.getMessage());
        }

        // Fallback: prompt user for password
        String username = DEFAULT_USER;
        boolean connected = false;

        while (!connected) {
            System.out.print("Enter MySQL root password: ");
            String password = (scanner != null) ? scanner.nextLine() : "";

            try {
                connection = DriverManager.getConnection(fullUrl, username, password);
                connected = true;
                System.out.println("✅ Connected to MySQL successfully (Database: " + DB_NAME + ")!");

                initDatabaseTables();
                seedDefaultLibrarian();

            } catch (SQLException e) {
                System.out.println("❌ Could not connect to MySQL: " + e.getMessage());
                System.out.println("   Please check your password and make sure MySQL service is running.");
                System.out.print("   Do you want to retry? (y/n): ");
                String retry = (scanner != null) ? scanner.nextLine().trim() : "n";
                if (!retry.equalsIgnoreCase("y")) {
                    System.out.println("Exiting application.");
                    System.exit(1);
                }
            }
        }
    }

    /**
     * Overloaded constructor for automated testing or programmatic connection.
     *
     * @param url      Full JDBC URL
     * @param username Database username
     * @param password Database password
     * @throws SQLException If connection fails
     */
    public DatabaseConnection(String url, String username, String password) throws SQLException {
        this.connection = DriverManager.getConnection(url, username, password);
        initDatabaseTables();
        seedDefaultLibrarian();
    }

    /**
     * Overloaded constructor for injecting an existing Connection (e.g. In-Memory H2 for Unit/Integration tests).
     *
     * @param connection Existing JDBC Connection
     * @throws SQLException If initialization fails
     */
    public DatabaseConnection(Connection connection) throws SQLException {
        this.connection = connection;
        initDatabaseTables();
        seedDefaultLibrarian();
    }

    /**
     * Creates all necessary tables if they do not already exist.
     */
    public void initDatabaseTables() {
        try (Statement stmt = connection.createStatement()) {

            // 1. Table: librarians
            String createLibrarians = "CREATE TABLE IF NOT EXISTS librarians ("
                    + "librarian_id VARCHAR(50) PRIMARY KEY, "
                    + "password VARCHAR(255) NOT NULL, "
                    + "name VARCHAR(255) NOT NULL"
                    + ");";
            stmt.execute(createLibrarians);

            // 2. Table: students
            String createStudents = "CREATE TABLE IF NOT EXISTS students ("
                    + "roll_no VARCHAR(50) PRIMARY KEY, "
                    + "student_name VARCHAR(255) NOT NULL"
                    + ");";
            stmt.execute(createStudents);

            // 3. Table: books
            String createBooks = "CREATE TABLE IF NOT EXISTS books ("
                    + "book_id VARCHAR(50) PRIMARY KEY, "
                    + "title VARCHAR(255) NOT NULL, "
                    + "author VARCHAR(255) NOT NULL, "
                    + "publisher VARCHAR(255) NOT NULL, "
                    + "total_copies INT NOT NULL, "
                    + "available_copies INT NOT NULL"
                    + ");";
            stmt.execute(createBooks);

            // 4. Table: loans
            String createLoans = "CREATE TABLE IF NOT EXISTS loans ("
                    + "loan_id VARCHAR(50) PRIMARY KEY, "
                    + "roll_no VARCHAR(50) NOT NULL, "
                    + "student_name VARCHAR(255) NOT NULL, "
                    + "book_id VARCHAR(50) NOT NULL, "
                    + "book_title VARCHAR(255) NOT NULL, "
                    + "issue_date DATE NOT NULL, "
                    + "due_date DATE NOT NULL, "
                    + "return_date DATE NULL, "
                    + "renewal_count INT NOT NULL DEFAULT 0, "
                    + "returned BOOLEAN NOT NULL DEFAULT FALSE, "
                    + "fine_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00, "
                    + "fine_paid BOOLEAN NOT NULL DEFAULT FALSE, "
                    + "FOREIGN KEY (roll_no) REFERENCES students(roll_no) ON UPDATE CASCADE, "
                    + "FOREIGN KEY (book_id) REFERENCES books(book_id) ON UPDATE CASCADE"
                    + ");";
            stmt.execute(createLoans);

        } catch (SQLException e) {
            System.out.println("⚠️ Warning during table initialization: " + e.getMessage());
        }
    }

    /**
     * Seeds the default librarian account (lib123 / password123) if no librarians exist.
     */
    public void seedDefaultLibrarian() {
        String countSql = "SELECT COUNT(*) FROM librarians";
        String insertSql = "INSERT INTO librarians (librarian_id, password, name) VALUES (?, ?, ?)";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(countSql)) {

            if (rs.next() && rs.getInt(1) == 0) {
                try (PreparedStatement pstmt = connection.prepareStatement(insertSql)) {
                    pstmt.setString(1, "lib123");
                    pstmt.setString(2, "password123");
                    pstmt.setString(3, "Default Librarian");
                    pstmt.executeUpdate();
                    System.out.println("ℹ️  Default librarian created → ID: lib123 | Password: password123");
                }
            }
        } catch (SQLException e) {
            System.out.println("⚠️ Warning during librarian seeding: " + e.getMessage());
        }
    }

    /**
     * Gets the active JDBC Connection.
     *
     * @return Connection object
     */
    public Connection getConnection() {
        return connection;
    }

    /**
     * Closes the active database connection and stops the MySQL cleanup thread.
     */
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("🔌 Database connection closed.");
            }
        } catch (SQLException e) {
            System.out.println("⚠️ Error closing connection: " + e.getMessage());
        } finally {
            // Cleanly shutdown MySQL driver background thread to avoid lingering warnings in Maven
            try {
                com.mysql.cj.jdbc.AbandonedConnectionCleanupThread.checkedShutdown();
            } catch (Throwable ignored) {
            }
        }
    }
}
