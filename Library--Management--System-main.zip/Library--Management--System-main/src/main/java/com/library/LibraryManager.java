package com.library;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * LibraryManager.java — Contains ALL core library logic using MySQL via JDBC.
 *
 * This class handles:
 *   - Adding and editing books
 *   - Checking available books
 *   - Issuing books to students (with 30-day due date)
 *   - Renewing books (only within the 30-day window)
 *   - Returning books (with automatic overdue fine calculation at ₹50/day)
 *   - Paying fines (student side)
 *   - Collecting fines (librarian side)
 *   - Viewing personal borrowing history
 *   - Overdue report dashboard (librarian side)
 *
 * All operations use parameterized PreparedStatements to guarantee SQL injection safety
 * and ACID transactions for multi-table updates.
 */
public class LibraryManager {

    private Connection connection;
    private Scanner scanner;

    public LibraryManager(DatabaseConnection db, Scanner scanner) {
        this.connection = db.getConnection();
        this.scanner = scanner;
    }

    public LibraryManager(DatabaseConnection db) {
        this.connection = db.getConnection();
        this.scanner = null;
    }

    // ======================================================================
    //                      INPUT HELPER METHODS
    // ======================================================================

    private String readNonEmptyString(String prompt) {
        if (scanner == null) return "";
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("⚠️  Input cannot be empty. Please try again.");
        }
    }

    private int readPositiveInt(String prompt) {
        if (scanner == null) return 0;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("⚠️  Please enter a number greater than 0.");
            } catch (NumberFormatException e) {
                System.out.println("⚠️  Invalid number. Please enter a valid positive integer.");
            }
        }
    }

    // ======================================================================
    //                       BOOK MANAGEMENT (Librarian)
    // ======================================================================

    /**
     * Programmatic method to add a book (usable in tests and CLI).
     */
    public boolean addBook(String bookId, String title, String author, String publisher, int totalCopies) {
        if (bookId == null || bookId.trim().isEmpty() || totalCopies <= 0) {
            return false;
        }

        // Check if bookId already exists
        String checkSql = "SELECT book_id FROM books WHERE book_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setString(1, bookId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    return false; // Duplicate book ID
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error while checking book: " + e.getMessage());
            return false;
        }

        String insertSql = "INSERT INTO books (book_id, title, author, publisher, total_copies, available_copies) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement insertStmt = connection.prepareStatement(insertSql)) {
            insertStmt.setString(1, bookId);
            insertStmt.setString(2, title);
            insertStmt.setString(3, author);
            insertStmt.setString(4, publisher);
            insertStmt.setInt(5, totalCopies);
            insertStmt.setInt(6, totalCopies); // All copies available initially

            int affected = insertStmt.executeUpdate();
            return affected > 0;
        } catch (SQLException e) {
            System.out.println("❌ Database error adding book: " + e.getMessage());
            return false;
        }
    }

    public void addBook() {
        System.out.println("\n========== ADD NEW BOOK ==========");
        String bookId = readNonEmptyString("Enter Book ID: ");

        // Check exists for user prompt
        String checkSql = "SELECT book_id FROM books WHERE book_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setString(1, bookId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("❌ A book with ID '" + bookId + "' already exists!");
                    return;
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error checking book: " + e.getMessage());
            return;
        }

        String title = readNonEmptyString("Enter Title: ");
        String author = readNonEmptyString("Enter Author: ");
        String publisher = readNonEmptyString("Enter Publisher: ");
        int totalCopies = readPositiveInt("Enter Total Copies: ");

        boolean success = addBook(bookId, title, author, publisher, totalCopies);
        if (success) {
            System.out.println("✅ Book added successfully! [" + bookId + "] " + title);
        } else {
            System.out.println("❌ Failed to add book.");
        }
    }

    /**
     * Programmatic method to edit a book.
     */
    public boolean editBook(String bookId, String newTitle, String newAuthor, String newPublisher, Integer newTotalCopies) {
        String selectSql = "SELECT * FROM books WHERE book_id = ?";
        try (PreparedStatement selectStmt = connection.prepareStatement(selectSql)) {
            selectStmt.setString(1, bookId);
            try (ResultSet rs = selectStmt.executeQuery()) {
                if (!rs.next()) {
                    return false;
                }

                String currentTitle = rs.getString("title");
                String currentAuthor = rs.getString("author");
                String currentPublisher = rs.getString("publisher");
                int currentTotal = rs.getInt("total_copies");
                int currentAvailable = rs.getInt("available_copies");

                String title = (newTitle != null && !newTitle.trim().isEmpty()) ? newTitle : currentTitle;
                String author = (newAuthor != null && !newAuthor.trim().isEmpty()) ? newAuthor : currentAuthor;
                String publisher = (newPublisher != null && !newPublisher.trim().isEmpty()) ? newPublisher : currentPublisher;

                int copiesOut = currentTotal - currentAvailable;
                int total = (newTotalCopies != null && newTotalCopies >= 0) ? newTotalCopies : currentTotal;

                if (total < copiesOut) {
                    total = copiesOut; // Minimum possible
                }
                int available = total - copiesOut;

                String updateSql = "UPDATE books SET title = ?, author = ?, publisher = ?, "
                        + "total_copies = ?, available_copies = ? WHERE book_id = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                    updateStmt.setString(1, title);
                    updateStmt.setString(2, author);
                    updateStmt.setString(3, publisher);
                    updateStmt.setInt(4, total);
                    updateStmt.setInt(5, available);
                    updateStmt.setString(6, bookId);

                    return updateStmt.executeUpdate() > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error while editing book: " + e.getMessage());
            return false;
        }
    }

    public void editBook() {
        System.out.println("\n========== EDIT BOOK ==========");
        String bookId = readNonEmptyString("Enter Book ID to edit: ");

        String selectSql = "SELECT * FROM books WHERE book_id = ?";
        try (PreparedStatement selectStmt = connection.prepareStatement(selectSql)) {
            selectStmt.setString(1, bookId);

            try (ResultSet rs = selectStmt.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("❌ No book found with ID: " + bookId);
                    return;
                }

                String currentTitle = rs.getString("title");
                String currentAuthor = rs.getString("author");
                String currentPublisher = rs.getString("publisher");
                int currentTotal = rs.getInt("total_copies");
                int currentAvailable = rs.getInt("available_copies");

                System.out.println("\nCurrent Details:");
                System.out.println("  Title     : " + currentTitle);
                System.out.println("  Author    : " + currentAuthor);
                System.out.println("  Publisher : " + currentPublisher);
                System.out.println("  Total     : " + currentTotal);
                System.out.println("  Available : " + currentAvailable);

                System.out.println("\n(Press Enter to keep current value)");

                System.out.print("New Title [" + currentTitle + "]: ");
                String newTitle = scanner.nextLine().trim();

                System.out.print("New Author [" + currentAuthor + "]: ");
                String newAuthor = scanner.nextLine().trim();

                System.out.print("New Publisher [" + currentPublisher + "]: ");
                String newPublisher = scanner.nextLine().trim();

                System.out.print("New Total Copies [" + currentTotal + "]: ");
                String totalInput = scanner.nextLine().trim();

                Integer newTotal = null;
                if (!totalInput.isEmpty()) {
                    try {
                        newTotal = Integer.parseInt(totalInput);
                    } catch (NumberFormatException e) {
                        System.out.println("⚠️  Invalid number. Keeping old total copies.");
                    }
                }

                boolean updated = editBook(bookId, newTitle, newAuthor, newPublisher, newTotal);
                if (updated) {
                    System.out.println("✅ Book updated successfully!");
                } else {
                    System.out.println("❌ Failed to update book.");
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error while editing book: " + e.getMessage());
        }
    }

    // ======================================================================
    //                       CHECK AVAILABLE BOOKS
    // ======================================================================

    public List<Book> getAvailableBooks() {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT book_id, title, author, publisher, total_copies, available_copies FROM books WHERE available_copies > 0";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(new Book(
                        rs.getString("book_id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("publisher"),
                        rs.getInt("total_copies"),
                        rs.getInt("available_copies")
                ));
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error retrieving books: " + e.getMessage());
        }
        return list;
    }

    public void checkAvailableBooks() {
        System.out.println("\n========== AVAILABLE BOOKS ==========");
        List<Book> books = getAvailableBooks();

        if (books.isEmpty()) {
            System.out.println("No books are currently available.");
        } else {
            System.out.printf("%-10s %-30s %-20s %-20s %-10s%n",
                    "Book ID", "Title", "Author", "Publisher", "Available");
            System.out.println("-".repeat(95));

            for (Book b : books) {
                System.out.printf("%-10s %-30s %-20s %-20s %-10d%n",
                        b.getBookId(),
                        b.getTitle(),
                        b.getAuthor(),
                        b.getPublisher(),
                        b.getAvailableCopies());
            }
        }
        System.out.println("======================================\n");
    }

    // ======================================================================
    //                       ISSUE BOOK
    // ======================================================================

    /**
     * Programmatic method to issue a book. Returns the created loanId or null if failed.
     */
    public String issueBook(String rollNo, String studentName, String bookId) {
        if (rollNo == null || bookId == null) return null;

        try {
            // Check book existence and available copies
            String bookSql = "SELECT title, available_copies FROM books WHERE book_id = ?";
            String bookTitle = null;
            int availableCopies = 0;

            try (PreparedStatement stmt = connection.prepareStatement(bookSql)) {
                stmt.setString(1, bookId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (!rs.next()) {
                        return null; // Book not found
                    }
                    bookTitle = rs.getString("title");
                    availableCopies = rs.getInt("available_copies");
                }
            }

            if (availableCopies <= 0) {
                return null; // No copies
            }

            // Check if student already has active loan for this book
            String loanCheckSql = "SELECT COUNT(*) FROM loans WHERE roll_no = ? AND book_id = ? AND returned = FALSE";
            try (PreparedStatement stmt = connection.prepareStatement(loanCheckSql)) {
                stmt.setString(1, rollNo);
                stmt.setString(2, bookId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return null; // Already has active copy
                    }
                }
            }

            // Transaction execution
            connection.setAutoCommit(false);

            // Ensure student record exists (insert or ignore/update)
            String studentCheckSql = "SELECT roll_no FROM students WHERE roll_no = ?";
            boolean studentExists = false;
            try (PreparedStatement stmt = connection.prepareStatement(studentCheckSql)) {
                stmt.setString(1, rollNo);
                try (ResultSet rs = stmt.executeQuery()) {
                    studentExists = rs.next();
                }
            }

            if (!studentExists) {
                String insertStudentSql = "INSERT INTO students (roll_no, student_name) VALUES (?, ?)";
                try (PreparedStatement stmt = connection.prepareStatement(insertStudentSql)) {
                    stmt.setString(1, rollNo);
                    stmt.setString(2, studentName);
                    stmt.executeUpdate();
                }
            }

            LocalDate issueDate = LocalDate.now();
            LocalDate dueDate = issueDate.plusDays(30);
            String loanId = "L" + System.currentTimeMillis();

            String insertLoanSql = "INSERT INTO loans (loan_id, roll_no, student_name, book_id, book_title, "
                    + "issue_date, due_date, return_date, renewal_count, returned, fine_amount, fine_paid) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 0, FALSE, 0.00, FALSE)";
            try (PreparedStatement stmt = connection.prepareStatement(insertLoanSql)) {
                stmt.setString(1, loanId);
                stmt.setString(2, rollNo);
                stmt.setString(3, studentName);
                stmt.setString(4, bookId);
                stmt.setString(5, bookTitle);
                stmt.setDate(6, Date.valueOf(issueDate));
                stmt.setDate(7, Date.valueOf(dueDate));
                stmt.executeUpdate();
            }

            String updateCopiesSql = "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(updateCopiesSql)) {
                stmt.setString(1, bookId);
                stmt.executeUpdate();
            }

            connection.commit();
            return loanId;

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                // ignore
            }
            System.out.println("❌ Database error during book issuance: " + e.getMessage());
            return null;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                // ignore
            }
        }
    }

    public void issueBook(String rollNo, String studentName) {
        System.out.println("\n========== ISSUE BOOK ==========");
        String bookId = readNonEmptyString("Enter Book ID to issue: ");

        String loanId = issueBook(rollNo, studentName, bookId);
        if (loanId != null) {
            System.out.println("✅ Book issued successfully!");
            System.out.println("   Loan ID : " + loanId);
            System.out.println("   Student : " + studentName + " (Roll No: " + rollNo + ")");
            System.out.println("   Due Date: " + LocalDate.now().plusDays(30) + " (30 days)");
        } else {
            System.out.println("❌ Could not issue book. Either book not found, 0 copies available, or duplicate active borrow.");
        }
    }

    public void issueBookAsLibrarian() {
        System.out.println("\n--- Librarian: Issue a Book to a Student ---");
        String rollNo = readNonEmptyString("Enter Student Roll Number: ");
        String studentName = readNonEmptyString("Enter Student Name: ");
        issueBook(rollNo, studentName);
    }

    // ======================================================================
    //                       RENEW BOOK
    // ======================================================================

    /**
     * Programmatic method to renew a book. Returns true if renewal succeeded, false if not allowed (e.g. overdue).
     */
    public boolean renewBook(String rollNo, String loanId) {
        String checkLoanSql = "SELECT due_date, renewal_count FROM loans WHERE loan_id = ? AND roll_no = ? AND returned = FALSE";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkLoanSql)) {
            checkStmt.setString(1, loanId);
            checkStmt.setString(2, rollNo);

            try (ResultSet rs = checkStmt.executeQuery()) {
                if (!rs.next()) {
                    return false;
                }

                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                LocalDate today = LocalDate.now();

                // Renewal only allowed on or before due date
                if (today.isAfter(dueDate)) {
                    return false; // Overdue
                }

                LocalDate newDueDate = dueDate.plusDays(30);
                int newRenewalCount = rs.getInt("renewal_count") + 1;

                String updateSql = "UPDATE loans SET due_date = ?, renewal_count = ? WHERE loan_id = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                    updateStmt.setDate(1, Date.valueOf(newDueDate));
                    updateStmt.setInt(2, newRenewalCount);
                    updateStmt.setString(3, loanId);
                    return updateStmt.executeUpdate() > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error during renewal: " + e.getMessage());
            return false;
        }
    }

    public void renewBook(String rollNo) {
        System.out.println("\n========== RENEW BOOK ==========");

        String querySql = "SELECT loan_id, book_id, book_title, issue_date, due_date, renewal_count "
                + "FROM loans WHERE roll_no = ? AND returned = FALSE";

        try (PreparedStatement stmt = connection.prepareStatement(querySql)) {
            stmt.setString(1, rollNo);

            List<String> activeLoanIds = new ArrayList<>();
            try (ResultSet rs = stmt.executeQuery()) {
                System.out.println("Your active loans:");
                System.out.printf("%-15s %-10s %-30s %-12s %-12s %-8s%n",
                        "Loan ID", "Book ID", "Title", "Issue Date", "Due Date", "Renewals");
                System.out.println("-".repeat(100));

                while (rs.next()) {
                    String lid = rs.getString("loan_id");
                    activeLoanIds.add(lid);
                    System.out.printf("%-15s %-10s %-30s %-12s %-12s %-8d%n",
                            lid,
                            rs.getString("book_id"),
                            rs.getString("book_title"),
                            rs.getDate("issue_date").toString(),
                            rs.getDate("due_date").toString(),
                            rs.getInt("renewal_count"));
                }
            }

            if (activeLoanIds.isEmpty()) {
                System.out.println("You have no active loans to renew.");
                return;
            }

            String loanId = readNonEmptyString("\nEnter Loan ID to renew: ");

            boolean renewed = renewBook(rollNo, loanId);
            if (renewed) {
                System.out.println("✅ Book renewed successfully! (+30 days extended)");
            } else {
                System.out.println("❌ Renewal failed! Book may be overdue, already returned, or invalid loan ID.");
            }

        } catch (SQLException e) {
            System.out.println("❌ Database error during renewal: " + e.getMessage());
        }
    }

    // ======================================================================
    //                       RETURN BOOK
    // ======================================================================

    /**
     * Programmatic return method. Returns calculated fine amount (>= 0), or -1 if loan not found.
     */
    public double returnBook(String rollNo, String bookId) {
        String selectLoanSql = "SELECT loan_id, book_title, due_date FROM loans "
                + "WHERE roll_no = ? AND book_id = ? AND returned = FALSE";

        try (PreparedStatement stmt = connection.prepareStatement(selectLoanSql)) {
            stmt.setString(1, rollNo);
            stmt.setString(2, bookId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (!rs.next()) {
                    return -1.0; // Not found
                }

                String loanId = rs.getString("loan_id");
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                LocalDate returnDate = LocalDate.now();
                double fineAmount = 0.0;

                if (returnDate.isAfter(dueDate)) {
                    long overdueDays = ChronoUnit.DAYS.between(dueDate, returnDate);
                    fineAmount = overdueDays * 50.0; // ₹50/day
                }

                connection.setAutoCommit(false);

                String updateLoanSql = "UPDATE loans SET return_date = ?, returned = TRUE, fine_amount = ? WHERE loan_id = ?";
                try (PreparedStatement updateStmt = connection.prepareStatement(updateLoanSql)) {
                    updateStmt.setDate(1, Date.valueOf(returnDate));
                    updateStmt.setDouble(2, fineAmount);
                    updateStmt.setString(3, loanId);
                    updateStmt.executeUpdate();
                }

                String updateCopiesSql = "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?";
                try (PreparedStatement updateCopiesStmt = connection.prepareStatement(updateCopiesSql)) {
                    updateCopiesStmt.setString(1, bookId);
                    updateCopiesStmt.executeUpdate();
                }

                connection.commit();
                return fineAmount;
            }
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                // ignore
            }
            System.out.println("❌ Database error during return: " + e.getMessage());
            return -1.0;
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
                // ignore
            }
        }
    }

    public void returnBook(String rollNo) {
        System.out.println("\n========== RETURN BOOK ==========");
        String bookId = readNonEmptyString("Enter Book ID to return: ");

        double fine = returnBook(rollNo, bookId);
        if (fine < 0) {
            System.out.println("❌ No active loan found for Book ID '" + bookId + "' under Roll No '" + rollNo + "'.");
        } else if (fine == 0) {
            System.out.println("✅ Book returned on time! No fine incurred.");
        } else {
            System.out.printf("⚠️  Book returned overdue! Overdue Fine: ₹%.0f%n", fine);
        }
    }

    public void returnBookAsLibrarian() {
        System.out.println("\n--- Librarian: Return a Book for a Student ---");
        String rollNo = readNonEmptyString("Enter Student Roll Number: ");
        returnBook(rollNo);
    }

    // ======================================================================
    //                       PAY FINE (Student)
    // ======================================================================

    public boolean payFineForLoan(String rollNo, String loanId) {
        String paySql = "UPDATE loans SET fine_paid = TRUE WHERE loan_id = ? AND roll_no = ? AND fine_paid = FALSE AND fine_amount > 0";
        try (PreparedStatement payStmt = connection.prepareStatement(paySql)) {
            payStmt.setString(1, loanId);
            payStmt.setString(2, rollNo);
            return payStmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error paying fine: " + e.getMessage());
            return false;
        }
    }

    public boolean payAllFines(String rollNo) {
        String payAllSql = "UPDATE loans SET fine_paid = TRUE WHERE roll_no = ? AND fine_paid = FALSE AND fine_amount > 0";
        try (PreparedStatement payAllStmt = connection.prepareStatement(payAllSql)) {
            payAllStmt.setString(1, rollNo);
            return payAllStmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("❌ Error paying all fines: " + e.getMessage());
            return false;
        }
    }

    public void payFine(String rollNo) {
        System.out.println("\n========== PAY FINE ==========");

        updateLiveOverdueFines(rollNo);

        String querySql = "SELECT loan_id, book_id, book_title, due_date, returned, fine_amount "
                + "FROM loans WHERE roll_no = ? AND fine_paid = FALSE AND fine_amount > 0";

        try (PreparedStatement stmt = connection.prepareStatement(querySql)) {
            stmt.setString(1, rollNo);

            List<String> unpaidLoanIds = new ArrayList<>();
            double totalUnpaid = 0.0;

            try (ResultSet rs = stmt.executeQuery()) {
                System.out.printf("%-15s %-10s %-25s %-12s %-12s %-10s%n",
                        "Loan ID", "Book ID", "Title", "Due Date", "Status", "Fine (₹)");
                System.out.println("-".repeat(90));

                while (rs.next()) {
                    String lid = rs.getString("loan_id");
                    unpaidLoanIds.add(lid);
                    double fine = rs.getDouble("fine_amount");
                    totalUnpaid += fine;

                    String status = rs.getBoolean("returned") ? "Returned" : "Active (Overdue)";

                    System.out.printf("%-15s %-10s %-25s %-12s %-12s ₹%-9.0f%n",
                            lid,
                            rs.getString("book_id"),
                            rs.getString("book_title"),
                            rs.getDate("due_date").toString(),
                            status,
                            fine);
                }
            }

            if (unpaidLoanIds.isEmpty()) {
                System.out.println("🎉 You have no unpaid fines. All clear!");
                return;
            }

            System.out.println("-".repeat(90));
            System.out.printf("Total Unpaid Fine: ₹%.0f%n%n", totalUnpaid);

            System.out.println("Options:");
            System.out.println("  1. Pay fine for a specific loan (enter Loan ID)");
            System.out.println("  2. Pay all unpaid fines");
            System.out.println("  3. Cancel");

            String choice = readNonEmptyString("Enter choice (1/2/3): ");

            if (choice.equals("1")) {
                String loanId = readNonEmptyString("Enter Loan ID to pay fine for: ");
                boolean paid = payFineForLoan(rollNo, loanId);
                if (paid) {
                    System.out.println("✅ Fine paid successfully for Loan ID: " + loanId);
                } else {
                    System.out.println("❌ No unpaid fine found for Loan ID: " + loanId);
                }
            } else if (choice.equals("2")) {
                boolean allPaid = payAllFines(rollNo);
                if (allPaid) {
                    System.out.printf("✅ All fines totalling ₹%.0f paid successfully!%n", totalUnpaid);
                }
            } else {
                System.out.println("Payment cancelled.");
            }

        } catch (SQLException e) {
            System.out.println("❌ Database error during fine payment: " + e.getMessage());
        }
    }

    public void updateLiveOverdueFines(String rollNo) {
        String sql = "SELECT loan_id, due_date FROM loans WHERE roll_no = ? AND returned = FALSE";
        LocalDate today = LocalDate.now();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, rollNo);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                    if (today.isAfter(dueDate)) {
                        long overdueDays = ChronoUnit.DAYS.between(dueDate, today);
                        double liveFine = overdueDays * 50.0;

                        String updateSql = "UPDATE loans SET fine_amount = ? WHERE loan_id = ?";
                        try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                            updateStmt.setDouble(1, liveFine);
                            updateStmt.setString(2, rs.getString("loan_id"));
                            updateStmt.executeUpdate();
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("⚠️ Warning updating live fines: " + e.getMessage());
        }
    }

    // ======================================================================
    //                       COLLECT FINE (Librarian)
    // ======================================================================

    public void collectFine() {
        System.out.println("\n========== COLLECT FINE ==========");
        String rollNo = readNonEmptyString("Enter Student Roll Number: ");
        updateLiveOverdueFines(rollNo);

        String querySql = "SELECT loan_id, book_id, book_title, due_date, returned, fine_amount "
                + "FROM loans WHERE roll_no = ? AND fine_paid = FALSE AND fine_amount > 0";

        try (PreparedStatement stmt = connection.prepareStatement(querySql)) {
            stmt.setString(1, rollNo);

            List<String> unpaidLoanIds = new ArrayList<>();
            double totalUnpaid = 0.0;

            try (ResultSet rs = stmt.executeQuery()) {
                System.out.println("\nUnpaid fines for Roll No: " + rollNo);
                System.out.printf("%-15s %-10s %-25s %-12s %-12s %-10s%n",
                        "Loan ID", "Book ID", "Title", "Due Date", "Status", "Fine (₹)");
                System.out.println("-".repeat(90));

                while (rs.next()) {
                    String lid = rs.getString("loan_id");
                    unpaidLoanIds.add(lid);
                    double fine = rs.getDouble("fine_amount");
                    totalUnpaid += fine;

                    String status = rs.getBoolean("returned") ? "Returned" : "Active (Overdue)";

                    System.out.printf("%-15s %-10s %-25s %-12s %-12s ₹%-9.0f%n",
                            lid,
                            rs.getString("book_id"),
                            rs.getString("book_title"),
                            rs.getDate("due_date").toString(),
                            status,
                            fine);
                }
            }

            if (unpaidLoanIds.isEmpty()) {
                System.out.println("🎉 This student has no unpaid fines.");
                return;
            }

            System.out.println("-".repeat(90));
            System.out.printf("Total Unpaid Fine: ₹%.0f%n%n", totalUnpaid);

            System.out.println("Options:");
            System.out.println("  1. Collect fine for a specific loan (enter Loan ID)");
            System.out.println("  2. Collect all unpaid fines");
            System.out.println("  3. Cancel");

            String choice = readNonEmptyString("Enter choice (1/2/3): ");

            if (choice.equals("1")) {
                String loanId = readNonEmptyString("Enter Loan ID: ");
                boolean paid = payFineForLoan(rollNo, loanId);
                if (paid) {
                    System.out.println("✅ Fine collected successfully for Loan ID: " + loanId);
                } else {
                    System.out.println("❌ No unpaid fine found for Loan ID: " + loanId);
                }
            } else if (choice.equals("2")) {
                boolean allPaid = payAllFines(rollNo);
                if (allPaid) {
                    System.out.printf("✅ Total fine of ₹%.0f collected successfully!%n", totalUnpaid);
                }
            } else {
                System.out.println("Collection cancelled.");
            }

        } catch (SQLException e) {
            System.out.println("❌ Database error during fine collection: " + e.getMessage());
        }
    }

    // ======================================================================
    //                       PERSONAL BORROWING HISTORY (Student)
    // ======================================================================

    public List<LoanRecord> getBorrowingHistory(String rollNo) {
        updateLiveOverdueFines(rollNo);
        List<LoanRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM loans WHERE roll_no = ? ORDER BY issue_date DESC";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, rollNo);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Date retDate = rs.getDate("return_date");
                    LocalDate returnDate = (retDate != null) ? retDate.toLocalDate() : null;

                    records.add(new LoanRecord(
                            rs.getString("loan_id"),
                            rs.getString("roll_no"),
                            rs.getString("student_name"),
                            rs.getString("book_id"),
                            rs.getString("book_title"),
                            rs.getDate("issue_date").toLocalDate(),
                            rs.getDate("due_date").toLocalDate(),
                            returnDate,
                            rs.getInt("renewal_count"),
                            rs.getBoolean("returned"),
                            rs.getDouble("fine_amount"),
                            rs.getBoolean("fine_paid")
                    ));
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Database error retrieving borrowing history: " + e.getMessage());
        }
        return records;
    }

    public void personalBorrowingHistory(String rollNo) {
        System.out.println("\n========== YOUR BORROWING HISTORY ==========");
        List<LoanRecord> history = getBorrowingHistory(rollNo);

        if (history.isEmpty()) {
            System.out.println("No borrowing history found.");
        } else {
            System.out.printf("%-14s %-8s %-22s %-11s %-11s %-16s %-8s %-10s %-8s%n",
                    "Loan ID", "BookID", "Title", "Issued", "Due", "Return/Status", "Renew", "Fine(₹)", "Paid?");
            System.out.println("-".repeat(115));

            LocalDate today = LocalDate.now();
            for (LoanRecord r : history) {
                String returnStatus;
                if (r.isReturned()) {
                    returnStatus = (r.getReturnDate() != null) ? r.getReturnDate().toString() : "Returned";
                } else {
                    returnStatus = today.isAfter(r.getDueDate()) ? "OVERDUE" : "Active";
                }

                String fineStr = r.getFineAmount() > 0 ? String.format("₹%.0f", r.getFineAmount()) : "-";
                String paidStr = r.getFineAmount() > 0 ? (r.isFinePaid() ? "Yes" : "No") : "-";

                String title = r.getBookTitle();
                if (title != null && title.length() > 20) {
                    title = title.substring(0, 17) + "...";
                }

                System.out.printf("%-14s %-8s %-22s %-11s %-11s %-16s %-8d %-10s %-8s%n",
                        r.getLoanId(),
                        r.getBookId(),
                        title,
                        r.getIssueDate().toString(),
                        r.getDueDate().toString(),
                        returnStatus,
                        r.getRenewalCount(),
                        fineStr,
                        paidStr);
            }
        }
        System.out.println("==============================================\n");
    }

    // ======================================================================
    //                       OVERDUE REPORT DASHBOARD (Librarian)
    // ======================================================================

    public void overdueReportDashboard() {
        System.out.println("\n========== OVERDUE REPORT DASHBOARD ==========");

        String sql = "SELECT * FROM loans WHERE returned = FALSE";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            LocalDate today = LocalDate.now();
            int overdueCount = 0;
            double totalOverdueFine = 0.0;

            System.out.printf("%-10s %-18s %-8s %-22s %-11s %-11s %-10s %-10s%n",
                    "Roll No", "Student", "BookID", "Title", "Issued", "Due", "Days Late", "Fine(₹)");
            System.out.println("-".repeat(105));

            while (rs.next()) {
                LocalDate dueDate = rs.getDate("due_date").toLocalDate();

                if (today.isAfter(dueDate)) {
                    long overdueDays = ChronoUnit.DAYS.between(dueDate, today);
                    double fine = overdueDays * 50.0;

                    overdueCount++;
                    totalOverdueFine += fine;

                    // Update live fine in database
                    String updateSql = "UPDATE loans SET fine_amount = ? WHERE loan_id = ?";
                    try (PreparedStatement updateStmt = connection.prepareStatement(updateSql)) {
                        updateStmt.setDouble(1, fine);
                        updateStmt.setString(2, rs.getString("loan_id"));
                        updateStmt.executeUpdate();
                    }

                    String title = rs.getString("book_title");
                    if (title != null && title.length() > 20) {
                        title = title.substring(0, 17) + "...";
                    }

                    System.out.printf("%-10s %-18s %-8s %-22s %-11s %-11s %-10d ₹%-9.0f%n",
                            rs.getString("roll_no"),
                            rs.getString("student_name"),
                            rs.getString("book_id"),
                            title,
                            rs.getDate("issue_date").toString(),
                            dueDate.toString(),
                            overdueDays,
                            fine);
                }
            }

            if (overdueCount == 0) {
                System.out.println("🎉 No overdue books! All books are within their return period.");
            } else {
                System.out.println("-".repeat(105));
                System.out.printf("📊 Summary: %d overdue book(s) | Total Fine: ₹%.0f%n", overdueCount, totalOverdueFine);
            }
            System.out.println("================================================\n");

        } catch (SQLException e) {
            System.out.println("❌ Database error retrieving overdue reports: " + e.getMessage());
        }
    }
}
