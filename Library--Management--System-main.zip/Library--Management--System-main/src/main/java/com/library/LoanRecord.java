package com.library;

import java.time.LocalDate;

/**
 * LoanRecord.java — A simple model class representing a borrowed book record.
 *
 * Each loan tracks:
 *   - loanId        : A unique ID for the loan (e.g., "L1700000000000")
 *   - rollNo        : The student's roll number who borrowed the book
 *   - studentName   : The student's name
 *   - bookId        : The ID of the borrowed book
 *   - bookTitle     : The title of the borrowed book (for easy display)
 *   - issueDate     : The date the book was issued
 *   - dueDate       : The date by which the book should be returned (issueDate + 30 days)
 *   - returnDate    : The date the book was actually returned (null if still borrowed)
 *   - renewalCount  : How many times this loan has been renewed
 *   - returned      : Whether the book has been returned (true/false)
 *   - fineAmount    : The overdue fine in ₹ (₹50 per overdue day)
 *   - finePaid      : Whether the fine has been paid (true/false)
 *
 * In MongoDB, each loan is a document in the 'loans' collection.
 */
public class LoanRecord {

    // ========== Fields ==========

    private String loanId;          // Unique loan identifier
    private String rollNo;          // Student's roll number
    private String studentName;     // Student's name
    private String bookId;          // ID of the borrowed book
    private String bookTitle;       // Title of the borrowed book
    private LocalDate issueDate;    // Date the book was issued
    private LocalDate dueDate;      // Date the book is due (issueDate + 30 days)
    private LocalDate returnDate;   // Date the book was returned (null if not yet returned)
    private int renewalCount;       // Number of times renewed
    private boolean returned;       // Has the book been returned?
    private double fineAmount;      // Fine in ₹ (₹50 per overdue day)
    private boolean finePaid;       // Has the fine been paid?

    // ========== Constructor ==========

    /**
     * Creates a new LoanRecord with all fields.
     */
    public LoanRecord(String loanId, String rollNo, String studentName,
                      String bookId, String bookTitle,
                      LocalDate issueDate, LocalDate dueDate, LocalDate returnDate,
                      int renewalCount, boolean returned,
                      double fineAmount, boolean finePaid) {
        this.loanId = loanId;
        this.rollNo = rollNo;
        this.studentName = studentName;
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.renewalCount = renewalCount;
        this.returned = returned;
        this.fineAmount = fineAmount;
        this.finePaid = finePaid;
    }

    // ========== Getters ==========

    public String getLoanId() {
        return loanId;
    }

    public String getRollNo() {
        return rollNo;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getBookId() {
        return bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public int getRenewalCount() {
        return renewalCount;
    }

    public boolean isReturned() {
        return returned;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public boolean isFinePaid() {
        return finePaid;
    }

    // ========== Setters ==========

    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public void setRenewalCount(int renewalCount) {
        this.renewalCount = renewalCount;
    }

    public void setReturned(boolean returned) {
        this.returned = returned;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public void setFinePaid(boolean finePaid) {
        this.finePaid = finePaid;
    }

    // ========== Display ==========

    /**
     * Returns a nicely formatted string showing loan details.
     */
    @Override
    public String toString() {
        String status = returned ? "Returned on " + returnDate : "Active (Not Returned)";
        String fineInfo = fineAmount > 0
                ? "₹" + String.format("%.0f", fineAmount) + (finePaid ? " (Paid)" : " (Unpaid)")
                : "No Fine";

        return "| Loan ID: " + loanId
             + " | Roll No: " + rollNo
             + " | Student: " + studentName
             + " | Book ID: " + bookId
             + " | Title: " + bookTitle
             + " | Issued: " + issueDate
             + " | Due: " + dueDate
             + " | Status: " + status
             + " | Renewals: " + renewalCount
             + " | Fine: " + fineInfo + " |";
    }
}
