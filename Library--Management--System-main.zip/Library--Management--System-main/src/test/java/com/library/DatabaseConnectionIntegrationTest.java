package com.library;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Integration Tests: DatabaseConnection & Schema Initialization")
public class DatabaseConnectionIntegrationTest {

    private static final String TEST_URL = "jdbc:h2:mem:db_init_test;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1";
    private Connection rawConnection;
    private DatabaseConnection dbConnection;

    @BeforeEach
    void setUp() throws SQLException {
        rawConnection = DriverManager.getConnection(TEST_URL, "sa", "");
        dbConnection = new DatabaseConnection(rawConnection);
    }

    @AfterEach
    void tearDown() throws SQLException {
        if (rawConnection != null && !rawConnection.isClosed()) {
            rawConnection.close();
        }
    }

    @Test
    @DisplayName("Should initialize all 4 tables in the database")
    void testTablesCreated() throws SQLException {
        String[] tables = {"librarians", "students", "books", "loans"};

        for (String table : tables) {
            String checkSql = "SELECT COUNT(*) FROM " + table;
            try (PreparedStatement stmt = rawConnection.prepareStatement(checkSql);
                 ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "Table should exist and be queryable: " + table);
            }
        }
    }

    @Test
    @DisplayName("Should seed default librarian (lib123 / password123)")
    void testDefaultLibrarianSeeded() throws SQLException {
        String sql = "SELECT name, password FROM librarians WHERE librarian_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(sql)) {
            stmt.setString(1, "lib123");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "Default librarian record should exist");
                assertEquals("Default Librarian", rs.getString("name"));
                assertEquals("password123", rs.getString("password"));
            }
        }
    }

    @Test
    @DisplayName("Calling seedDefaultLibrarian again should not insert duplicates")
    void testNoDuplicateSeeding() throws SQLException {
        dbConnection.seedDefaultLibrarian();

        String countSql = "SELECT COUNT(*) FROM librarians";
        try (PreparedStatement stmt = rawConnection.prepareStatement(countSql);
             ResultSet rs = stmt.executeQuery()) {
            assertTrue(rs.next());
            assertEquals(1, rs.getInt(1), "Librarians count should remain 1");
        }
    }
}
