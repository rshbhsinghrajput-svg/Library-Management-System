package com.library;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Unit Tests: Business Rules & Fine Calculations")
public class FineCalculationTest {

    @Test
    @DisplayName("Rule 1: Due date must be exactly 30 days after issue date")
    void testThirtyDayDueDateRule() {
        LocalDate issueDate = LocalDate.of(2026, 10, 1);
        LocalDate expectedDueDate = issueDate.plusDays(30);

        assertEquals(LocalDate.of(2026, 10, 31), expectedDueDate);
        assertEquals(30, ChronoUnit.DAYS.between(issueDate, expectedDueDate));
    }

    @Test
    @DisplayName("Rule 2: Renewal extends due date by exactly 30 days from current due date")
    void testRenewalExtensionRule() {
        LocalDate currentDueDate = LocalDate.of(2026, 10, 31);
        LocalDate newDueDate = currentDueDate.plusDays(30);

        assertEquals(LocalDate.of(2026, 11, 30), newDueDate);
        assertEquals(30, ChronoUnit.DAYS.between(currentDueDate, newDueDate));
    }

    @Test
    @DisplayName("Rule 3: Return on or before due date incurs ZERO fine")
    void testOnTimeReturnFineIsZero() {
        LocalDate dueDate = LocalDate.of(2026, 10, 31);
        LocalDate returnDateOnDue = LocalDate.of(2026, 10, 31);
        LocalDate returnDateEarly = LocalDate.of(2026, 10, 20);

        assertFalse(returnDateOnDue.isAfter(dueDate));
        assertFalse(returnDateEarly.isAfter(dueDate));

        double fineOnDue = returnDateOnDue.isAfter(dueDate) ? ChronoUnit.DAYS.between(dueDate, returnDateOnDue) * 50.0 : 0.0;
        double fineEarly = returnDateEarly.isAfter(dueDate) ? ChronoUnit.DAYS.between(dueDate, returnDateEarly) * 50.0 : 0.0;

        assertEquals(0.0, fineOnDue);
        assertEquals(0.0, fineEarly);
    }

    @Test
    @DisplayName("Rule 4: Overdue fine is exactly ₹50 per day past due date")
    void testOverdueFineCalculations() {
        LocalDate dueDate = LocalDate.of(2026, 10, 31);

        // Case A: 1 day late -> ₹50
        LocalDate return1DayLate = LocalDate.of(2026, 11, 1);
        long days1 = ChronoUnit.DAYS.between(dueDate, return1DayLate);
        assertEquals(1, days1);
        assertEquals(50.0, days1 * 50.0);

        // Case B: 10 days late -> ₹500
        LocalDate return10DaysLate = LocalDate.of(2026, 11, 10);
        long days10 = ChronoUnit.DAYS.between(dueDate, return10DaysLate);
        assertEquals(10, days10);
        assertEquals(500.0, days10 * 50.0);

        // Case C: 25 days late -> ₹1250
        LocalDate return25DaysLate = LocalDate.of(2026, 11, 25);
        long days25 = ChronoUnit.DAYS.between(dueDate, return25DaysLate);
        assertEquals(25, days25);
        assertEquals(1250.0, days25 * 50.0);
    }

    @Test
    @DisplayName("Rule 5: Renewal is disallowed once current date is strictly after due date")
    void testRenewalDisallowedWhenOverdue() {
        LocalDate dueDate = LocalDate.of(2026, 10, 31);
        LocalDate simulatedTodayOnDue = LocalDate.of(2026, 10, 31);
        LocalDate simulatedTodayOverdue = LocalDate.of(2026, 11, 1);

        // On due date: allowed
        assertFalse(simulatedTodayOnDue.isAfter(dueDate));

        // After due date: disallowed
        assertTrue(simulatedTodayOverdue.isAfter(dueDate));
    }
}
