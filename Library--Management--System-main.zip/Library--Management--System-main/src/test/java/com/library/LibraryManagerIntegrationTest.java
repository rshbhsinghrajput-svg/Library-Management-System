package com.library;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Integration Tests: Complete LibraryManager Business Workflows")
public class LibraryManagerIntegrationTest {

    private static final String TEST_URL = "jdbc:h2:mem:lms_workflow_test;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1";
    private Connection rawConnection;
    private DatabaseConnection dbConnection;
    private LibraryManager manager;

    @BeforeEach
    void setUp() throws SQLException {
        rawConnection = DriverManager.getConnection(TEST_URL, "sa", "");
        dbConnection = new DatabaseConnection(rawConnection);
        manager = new LibraryManager(dbConnection);
    }

    @AfterEach
    void tearDown() throws SQLException {
        // Drop all tables between test runs to ensure complete test isolation
        try (java.sql.Statement stmt = rawConnection.createStatement()) {
            stmt.execute("DROP ALL OBJECTS");
        }
        if (rawConnection != null && !rawConnection.isClosed()) {
            rawConnection.close();
        }
    }

    // ==========================================
    // Book Management Tests
    // ==========================================

    @Test
    @DisplayName("Add Book: successfully inserts new book and prevents duplicate Book ID")
    void testAddBookAndDuplicateRejection() {
        boolean added = manager.addBook("B001", "Clean Architecture", "Robert Martin", "Prentice Hall", 5);
        assertTrue(added, "Book should be added successfully");

        // Verify available copies equals total copies initially
        List<Book> available = manager.getAvailableBooks();
        assertEquals(1, available.size());
        assertEquals("B001", available.get(0).getBookId());
        assertEquals(5, available.get(0).getAvailableCopies());
        assertEquals(5, available.get(0).getTotalCopies());

        // Attempt adding same ID again
        boolean duplicateAdded = manager.addBook("B001", "Duplicate Book", "Author", "Pub", 2);
        assertFalse(duplicateAdded, "Duplicate book ID should be rejected");
    }

    @Test
    @DisplayName("Edit Book: updates title, publisher and adjusts copies safely")
    void testEditBookSafely() {
        manager.addBook("B002", "Effective Java", "Joshua Bloch", "Addison-Wesley", 3);

        boolean updated = manager.editBook("B002", "Effective Java (3rd Ed)", "Joshua Bloch", "Pearson", 5);
        assertTrue(updated, "Book edit should succeed");

        List<Book> books = manager.getAvailableBooks();
        assertEquals(1, books.size());
        assertEquals("Effective Java (3rd Ed)", books.get(0).getTitle());
        assertEquals(5, books.get(0).getTotalCopies());
        assertEquals(5, books.get(0).getAvailableCopies());
    }

    // ==========================================
    // Book Issuance & Limits Tests
    // ==========================================

    @Test
    @DisplayName("Issue Book: creates 30-day loan, registers student, decrements available copies")
    void testIssueBookWorkflow() throws SQLException {
        manager.addBook("B003", "Design Patterns", "Gang of Four", "Addison-Wesley", 2);

        String loanId = manager.issueBook("S101", "Alice Smith", "B003");
        assertNotNull(loanId, "Loan ID should be generated upon successful issue");

        // Check copies decremented from 2 to 1
        List<Book> books = manager.getAvailableBooks();
        assertEquals(1, books.get(0).getAvailableCopies());

        // Check student created in students table
        String studentSql = "SELECT student_name FROM students WHERE roll_no = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(studentSql)) {
            stmt.setString(1, "S101");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next());
                assertEquals("Alice Smith", rs.getString("student_name"));
            }
        }
    }

    @Test
    @DisplayName("Issue Book: rejects when available copies is 0")
    void testIssueBookFailsWhenZeroCopies() {
        manager.addBook("B004", "Algorithms", "Sedgewick", "Addison-Wesley", 1);

        String loan1 = manager.issueBook("S101", "Alice", "B004");
        assertNotNull(loan1);

        // Second issue attempt on zero available copies
        String loan2 = manager.issueBook("S102", "Bob", "B004");
        assertNull(loan2, "Should not issue book when available copies is 0");
    }

    @Test
    @DisplayName("Issue Book: rejects duplicate active borrow of same book by same student")
    void testIssueBookRejectsDuplicateBorrow() {
        manager.addBook("B005", "Operating Systems", "Silberschatz", "Wiley", 5);

        String loan1 = manager.issueBook("S101", "Alice", "B005");
        assertNotNull(loan1);

        String duplicateLoan = manager.issueBook("S101", "Alice", "B005");
        assertNull(duplicateLoan, "Student cannot borrow the same book twice simultaneously");
    }

    // ==========================================
    // Book Renewal Tests
    // ==========================================

    @Test
    @DisplayName("Renew Book: extends due date by 30 days and increments renewal count")
    void testRenewBookWorkflow() throws SQLException {
        manager.addBook("B006", "Computer Networks", "Tanenbaum", "Pearson", 3);
        String loanId = manager.issueBook("S101", "Alice", "B006");
        assertNotNull(loanId);

        boolean renewed = manager.renewBook("S101", loanId);
        assertTrue(renewed, "Renewal should succeed for active, non-overdue loan");

        String sql = "SELECT due_date, renewal_count FROM loans WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(sql)) {
            stmt.setString(1, loanId);
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next());
                LocalDate expectedDueDate = LocalDate.now().plusDays(60); // 30 + 30
                assertEquals(expectedDueDate, rs.getDate("due_date").toLocalDate());
                assertEquals(1, rs.getInt("renewal_count"));
            }
        }
    }

    @Test
    @DisplayName("Renew Book: disallows renewal if loan is already overdue")
    void testRenewBookFailsWhenOverdue() throws SQLException {
        manager.addBook("B007", "Databases", "Elmasri", "Pearson", 3);
        String loanId = manager.issueBook("S101", "Alice", "B007");

        // Artificially simulate an overdue due date in the past
        LocalDate pastDue = LocalDate.now().minusDays(5);
        String updateSql = "UPDATE loans SET due_date = ? WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(updateSql)) {
            stmt.setDate(1, Date.valueOf(pastDue));
            stmt.setString(2, loanId);
            stmt.executeUpdate();
        }

        boolean renewed = manager.renewBook("S101", loanId);
        assertFalse(renewed, "Overdue loan cannot be renewed");
    }

    // ==========================================
    // Return & Fine Tests
    // ==========================================

    @Test
    @DisplayName("Return Book: on-time return incurs ₹0 fine and restores available copies")
    void testReturnBookOnTime() {
        manager.addBook("B008", "AI: A Modern Approach", "Russell", "Pearson", 2);
        manager.issueBook("S101", "Alice", "B008");

        double fine = manager.returnBook("S101", "B008");
        assertEquals(0.0, fine, "On time return fine must be ₹0");

        // Verify available copies restored to 2
        List<Book> books = manager.getAvailableBooks();
        assertEquals(2, books.get(0).getAvailableCopies());
    }

    @Test
    @DisplayName("Return Book: overdue return calculates fine at ₹50 per day")
    void testReturnBookOverdueFine() throws SQLException {
        manager.addBook("B009", "Compilers", "Aho", "Addison-Wesley", 2);
        String loanId = manager.issueBook("S101", "Alice", "B009");

        // Simulate 4 days overdue
        LocalDate pastDue = LocalDate.now().minusDays(4);
        String updateSql = "UPDATE loans SET due_date = ? WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(updateSql)) {
            stmt.setDate(1, Date.valueOf(pastDue));
            stmt.setString(2, loanId);
            stmt.executeUpdate();
        }

        double fine = manager.returnBook("S101", "B009");
        assertEquals(200.0, fine, "Fine should be 4 days * ₹50 = ₹200");

        // Verify loan status in database
        String loanSql = "SELECT returned, fine_amount, fine_paid FROM loans WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(loanSql)) {
            stmt.setString(1, loanId);
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next());
                assertTrue(rs.getBoolean("returned"));
                assertEquals(200.0, rs.getDouble("fine_amount"));
                assertFalse(rs.getBoolean("fine_paid"));
            }
        }
    }

    // ==========================================
    // Fine Payment Tests
    // ==========================================

    @Test
    @DisplayName("Pay Fine: single loan payment and all fines payment mark fine_paid = true")
    void testPayFineWorkflows() throws SQLException {
        manager.addBook("B010", "Discrete Math", "Rosen", "McGraw-Hill", 2);
        String loanId = manager.issueBook("S101", "Alice", "B010");

        // Make it overdue by 3 days (fine = ₹150) and return it
        LocalDate pastDue = LocalDate.now().minusDays(3);
        String updateSql = "UPDATE loans SET due_date = ? WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(updateSql)) {
            stmt.setDate(1, Date.valueOf(pastDue));
            stmt.setString(2, loanId);
            stmt.executeUpdate();
        }
        manager.returnBook("S101", "B010");

        // Pay fine for specific loan
        boolean paid = manager.payFineForLoan("S101", loanId);
        assertTrue(paid, "Paying fine for specific loan should succeed");

        String checkSql = "SELECT fine_paid FROM loans WHERE loan_id = ?";
        try (PreparedStatement stmt = rawConnection.prepareStatement(checkSql)) {
            stmt.setString(1, loanId);
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next());
                assertTrue(rs.getBoolean("fine_paid"), "fine_paid should now be true");
            }
        }
    }

    // ==========================================
    // History & Reporting Tests
    // ==========================================

    @Test
    @DisplayName("Borrowing History: accurately retrieves past and active records")
    void testBorrowingHistoryRetrieval() {
        manager.addBook("B011", "Java Concurrency", "Goetz", "Addison-Wesley", 3);
        manager.issueBook("S102", "Bob", "B011");

        List<LoanRecord> history = manager.getBorrowingHistory("S102");
        assertEquals(1, history.size());
        assertEquals("B011", history.get(0).getBookId());
        assertEquals("Bob", history.get(0).getStudentName());
        assertFalse(history.get(0).isReturned());
    }
}
