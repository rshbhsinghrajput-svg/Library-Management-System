package com.library;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Unit Tests: LoanRecord Model")
public class LoanRecordTest {

    @Test
    @DisplayName("Should create LoanRecord with valid details and getters")
    void testLoanRecordCreation() {
        LocalDate issueDate = LocalDate.now();
        LocalDate dueDate = issueDate.plusDays(30);

        LoanRecord loan = new LoanRecord(
                "L001", "S101", "Alice", "B001", "Clean Code",
                issueDate, dueDate, null, 0, false, 0.0, false
        );

        assertEquals("L001", loan.getLoanId());
        assertEquals("S101", loan.getRollNo());
        assertEquals("Alice", loan.getStudentName());
        assertEquals("B001", loan.getBookId());
        assertEquals("Clean Code", loan.getBookTitle());
        assertEquals(issueDate, loan.getIssueDate());
        assertEquals(dueDate, loan.getDueDate());
        assertNull(loan.getReturnDate());
        assertEquals(0, loan.getRenewalCount());
        assertFalse(loan.isReturned());
        assertEquals(0.0, loan.getFineAmount());
        assertFalse(loan.isFinePaid());
    }

    @Test
    @DisplayName("Should mutate LoanRecord fields on return and fine payment")
    void testLoanRecordMutation() {
        LocalDate issueDate = LocalDate.of(2026, 1, 1);
        LocalDate dueDate = issueDate.plusDays(30);

        LoanRecord loan = new LoanRecord(
                "L002", "S102", "Bob", "B002", "Effective Java",
                issueDate, dueDate, null, 0, false, 0.0, false
        );

        LocalDate returnDate = LocalDate.of(2026, 2, 5); // 5 days overdue
        loan.setReturnDate(returnDate);
        loan.setReturned(true);
        loan.setFineAmount(250.0);
        loan.setFinePaid(true);
        loan.setRenewalCount(1);

        assertTrue(loan.isReturned());
        assertEquals(returnDate, loan.getReturnDate());
        assertEquals(250.0, loan.getFineAmount());
        assertTrue(loan.isFinePaid());
        assertEquals(1, loan.getRenewalCount());
    }

    @Test
    @DisplayName("toString should format loan details properly")
    void testToString() {
        LocalDate now = LocalDate.now();
        LoanRecord loan = new LoanRecord(
                "L003", "S103", "Charlie", "B003", "Design Patterns",
                now, now.plusDays(30), null, 0, false, 0.0, false
        );

        String str = loan.toString();
        assertTrue(str.contains("L003"));
        assertTrue(str.contains("Charlie"));
        assertTrue(str.contains("Design Patterns"));
    }
}
