package com.library;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Unit Tests: Book Model")
public class BookTest {

    @Test
    @DisplayName("Should create Book with valid details and getters")
    void testBookCreationAndGetters() {
        Book book = new Book("B001", "Clean Code", "Robert C. Martin", "Prentice Hall", 5, 5);

        assertEquals("B001", book.getBookId());
        assertEquals("Clean Code", book.getTitle());
        assertEquals("Robert C. Martin", book.getAuthor());
        assertEquals("Prentice Hall", book.getPublisher());
        assertEquals(5, book.getTotalCopies());
        assertEquals(5, book.getAvailableCopies());
    }

    @Test
    @DisplayName("Should update Book details via setters")
    void testBookSetters() {
        Book book = new Book("B001", "Old Title", "Old Author", "Old Pub", 3, 3);

        book.setTitle("New Title");
        book.setAuthor("New Author");
        book.setPublisher("New Pub");
        book.setTotalCopies(10);
        book.setAvailableCopies(8);

        assertEquals("New Title", book.getTitle());
        assertEquals("New Author", book.getAuthor());
        assertEquals("New Pub", book.getPublisher());
        assertEquals(10, book.getTotalCopies());
        assertEquals(8, book.getAvailableCopies());
    }

    @Test
    @DisplayName("toString should contain book ID and title")
    void testToString() {
        Book book = new Book("B101", "Refactoring", "Martin Fowler", "Addison-Wesley", 4, 2);
        String str = book.toString();

        assertTrue(str.contains("B101"));
        assertTrue(str.contains("Refactoring"));
        assertTrue(str.contains("Martin Fowler"));
    }
}
